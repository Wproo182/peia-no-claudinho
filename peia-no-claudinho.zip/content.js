// Peia no Claudinho: motor de efeitos injetado na aba
(() => {
  if (window.__destruidorDePaginas) return;
  window.__destruidorDePaginas = true;

  const Z = 2147483640;
  const ORDER = ['chicote', 'pedra', 'arma', 'arco'];
  const NAMES = { chicote: 'Chicote', pedra: 'Pedra', arma: 'Arma', arco: 'Arco e flecha' };
  const ICONS = {
    chicote: '<svg viewBox="0 0 24 24"><path d="M3 21l4.5-5"/><path d="M7.5 16c3-4 9.5-2 11.5-6.5S17 2 13 4.5"/></svg>',
    pedra: '<svg viewBox="0 0 24 24"><path d="M4 15l2.5-6.5L13 5l6 3.5L21 15l-5 4.5H8.5z"/><path d="M9 11l3 2 3.5-1"/></svg>',
    arma: '<svg viewBox="0 0 24 24"><path d="M2.5 7.5h18v4.5h-9l-1 2.5H8l-1.2 5H3.5l1.2-7.5H2.5z"/><path d="M20.5 7.5V6"/></svg>',
    arco: '<svg viewBox="0 0 24 24"><path d="M6 2.5c9.5 3.5 9.5 15.5 0 19"/><path d="M6 2.5v19"/><path d="M3 12h18"/><path d="M18 9l3 3-3 3"/></svg>'
  };

  const LASH_MS = 380;
  const CHARGE_MS = 900;
  const MAX_MARKS = 350;
  const MAX_PARTICLES = 700;

  const rand = (a, b) => a + Math.random() * (b - a);
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  const state = {
    active: false,
    weapon: 'chicote',
    x: innerWidth / 2,
    y: innerHeight / 2,
    down: false,
    chargeStart: 0,
    sound: true,
    hits: 0,
    recoil: 0,
    autoTimer: null,
    stoneReadyAt: 0,
    arrowReadyAt: 0,
    stoneShape: makeStoneShape(),
    muzzle: { x: 0, y: 0 },
    eject: { x: 0, y: 0 },
    bowTip: { x: 0, y: 0 }
  };

  let fx, ctx, marksLayer, hudHost, hudRoot;
  let dpr = 1, VW = innerWidth, VH = innerHeight;
  let raf = 0, last = 0, lash = null;
  const particles = [];
  const projectiles = [];
  const marks = [];
  const damaged = new Map();

  try {
    chrome.storage.local.get(['weapon', 'sound']).then((v) => {
      if (ORDER.includes(v.weapon) && !state.active) state.weapon = v.weapon;
      if (typeof v.sound === 'boolean') state.sound = v.sound;
      updateHud();
    }).catch(() => {});
  } catch {}

  // ---------- Estrutura ----------
  function build() {
    marksLayer = document.createElement('div');
    marksLayer.setAttribute('data-destruidor', 'marcas');
    marksLayer.style.cssText = `all:initial;position:absolute;left:0;top:0;width:0;height:0;overflow:visible;pointer-events:none;z-index:${Z};`;

    fx = document.createElement('canvas');
    fx.setAttribute('data-destruidor', 'efeitos');
    fx.style.cssText = `all:initial;position:fixed;left:0;top:0;width:100%;height:100%;z-index:${Z + 1};cursor:none;display:none;touch-action:none;`;
    ctx = fx.getContext('2d');

    buildHud();
    document.documentElement.append(marksLayer, fx, hudHost);
    resize();

    addEventListener('resize', resize);
    addEventListener('keydown', onKey, true);
    fx.addEventListener('pointerdown', onDown);
    fx.addEventListener('pointermove', onMove);
    fx.addEventListener('pointerup', onUp);
    fx.addEventListener('pointercancel', onUp);
    fx.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  function resize() {
    if (!fx) return;
    dpr = Math.min(devicePixelRatio || 1, 2);
    VW = document.documentElement.clientWidth || innerWidth;
    VH = document.documentElement.clientHeight || innerHeight;
    fx.width = Math.round(VW * dpr);
    fx.height = Math.round(VH * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function activate(weapon) {
    if (!fx) build();
    if (weapon) setWeapon(weapon);
    state.active = true;
    fx.style.display = 'block';
    hudHost.style.display = 'block';
    updateHud();
    if (!raf) {
      last = performance.now();
      raf = requestAnimationFrame(loop);
    }
  }

  function deactivate() {
    state.active = false;
    state.down = false;
    state.chargeStart = 0;
    clearInterval(state.autoTimer);
    state.autoTimer = null;
    lash = null;
    projectiles.length = 0;
    particles.length = 0;
    if (fx) {
      ctx.clearRect(0, 0, VW, VH);
      fx.style.display = 'none';
      hudHost.style.display = 'none';
    }
  }

  function setWeapon(w) {
    if (!ORDER.includes(w)) return;
    state.weapon = w;
    state.chargeStart = 0;
    state.down = false;
    clearInterval(state.autoTimer);
    try { chrome.storage.local.set({ weapon: w }).catch(() => {}); } catch {}
    updateHud();
  }

  function reset() {
    for (const d of damaged.values()) {
      d.tiltAnim?.cancel();
      d.fallAnim?.cancel();
    }
    damaged.clear();
    for (const m of marks) m.remove();
    marks.length = 0;
    particles.length = 0;
    state.hits = 0;
    updateHud();
  }

  // ---------- Entrada ----------
  function onMove(e) {
    state.x = e.clientX;
    state.y = e.clientY;
  }

  function onDown(e) {
    if (e.button !== 0) return;
    e.preventDefault();
    try { fx.setPointerCapture(e.pointerId); } catch {}
    onMove(e);
    state.down = true;
    audio();

    switch (state.weapon) {
      case 'chicote': startLash(); break;
      case 'pedra': throwStone(); break;
      case 'arma':
        shoot();
        clearInterval(state.autoTimer);
        state.autoTimer = setInterval(() => { if (state.down) shoot(); }, 115);
        break;
      case 'arco':
        if (performance.now() >= state.arrowReadyAt) {
          state.chargeStart = performance.now();
          tone(0.5, 'sawtooth', 70, 110, 0.04);
        }
        break;
    }
  }

  function onUp() {
    if (!state.down) return;
    state.down = false;
    clearInterval(state.autoTimer);
    state.autoTimer = null;
    if (state.weapon === 'arco' && state.chargeStart) {
      fireArrow();
      state.chargeStart = 0;
    }
  }

  function onKey(e) {
    if (!state.active) return;
    if (e.key === 'Escape') {
      deactivate();
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    const i = '1234'.indexOf(e.key);
    if (i >= 0 && !e.ctrlKey && !e.metaKey && !e.altKey) {
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      setWeapon(ORDER[i]);
      e.preventDefault();
      e.stopPropagation();
    }
  }

  // ---------- Loop ----------
  function loop(now) {
    if (!state.active) { raf = 0; return; }
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    state.recoil = Math.max(0, state.recoil - dt * 5);

    ctx.clearRect(0, 0, VW, VH);
    updateParticles(dt);
    updateProjectiles(now);

    switch (state.weapon) {
      case 'chicote': drawWhip(now); break;
      case 'pedra': drawStoneHand(now); break;
      case 'arma': drawGun(); break;
      case 'arco': drawBow(now); break;
    }
    drawCrosshair(now);
    raf = requestAnimationFrame(loop);
  }

  // ---------- Chicote ----------
  function whipAnchor() {
    return { x: VW * 0.66 + (state.x - VW / 2) * 0.15, y: VH - 34 };
  }

  function startLash() {
    if (lash && performance.now() - lash.t0 < LASH_MS * 0.7) return;
    lash = { t0: performance.now(), tx: state.x, ty: state.y, struck: false };
    noise(0.22, 'bandpass', 300, 0.35, 2600, 0.9);
  }

  function ropePoints(A, T, t) {
    const N = 36;
    const dx = T.x - A.x, dy = T.y - A.y;
    const L = Math.hypot(dx, dy) || 1;
    const nx = -dy / L, ny = dx / L;
    let reach, amp;
    if (t < 0.35) {
      const k = t / 0.35;
      reach = 0.55 - 0.15 * k;
      amp = L * 0.25 * k;
    } else if (t < 0.55) {
      const k = (t - 0.35) / 0.2;
      reach = 0.4 + 0.6 * (1 - (1 - k) * (1 - k));
      amp = L * 0.25 * (1 - k);
    } else {
      const k = (t - 0.55) / 0.45;
      reach = 1 - 0.45 * k;
      amp = L * 0.06 * Math.sin(k * Math.PI * 3) * (1 - k);
    }
    const pts = [];
    for (let i = 0; i <= N; i++) {
      const s = i / N;
      const off = amp * Math.sin(Math.PI * s) * Math.sin(Math.PI * 2 * (s * 1.2 - t * 2.5));
      pts.push({ x: A.x + dx * reach * s + nx * off, y: A.y + dy * reach * s + ny * off });
    }
    return pts;
  }

  function idleRope(A, now) {
    const E = { x: lerp(A.x, state.x, 0.4), y: lerp(A.y, state.y, 0.4) + 70 };
    const C = { x: (A.x + E.x) / 2 + Math.sin(now / 400) * 10, y: Math.max(A.y, E.y) + 40 };
    const pts = [];
    for (let i = 0; i <= 24; i++) {
      const s = i / 24, u = 1 - s;
      pts.push({ x: u * u * A.x + 2 * u * s * C.x + s * s * E.x, y: u * u * A.y + 2 * u * s * C.y + s * s * E.y });
    }
    return pts;
  }

  function drawWhip(now) {
    const A = whipAnchor();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1e1006';
    ctx.lineWidth = 17;
    ctx.beginPath(); ctx.moveTo(A.x + 26, VH + 40); ctx.lineTo(A.x, A.y); ctx.stroke();
    ctx.strokeStyle = '#6b3d1a';
    ctx.lineWidth = 11;
    ctx.beginPath(); ctx.moveTo(A.x + 26, VH + 40); ctx.lineTo(A.x, A.y); ctx.stroke();

    let pts = null;
    if (lash) {
      const t = (now - lash.t0) / LASH_MS;
      if (t >= 1) {
        lash = null;
      } else {
        pts = ropePoints(A, { x: lash.tx, y: lash.ty }, t);
        if (!lash.struck && t >= 0.55) {
          lash.struck = true;
          impactWhip(lash.tx, lash.ty, A);
        }
      }
    }
    if (!pts) pts = idleRope(A, now);

    for (let i = 0; i < pts.length - 1; i++) {
      const s = i / (pts.length - 1);
      ctx.strokeStyle = s < 0.85 ? '#4a2a10' : '#2b1a0c';
      ctx.lineWidth = lerp(7, 1.6, s);
      ctx.beginPath();
      ctx.moveTo(pts[i].x, pts[i].y);
      ctx.lineTo(pts[i + 1].x, pts[i + 1].y);
      ctx.stroke();
    }
  }

  function impactWhip(x, y, A) {
    const angle = Math.atan2(y - A.y, x - A.x) + Math.PI / 2 + rand(-0.35, 0.35);
    addMark(drawWelt(angle), x, y);
    for (let i = 0; i < 16; i++) {
      const a = rand(0, Math.PI * 2), v = rand(250, 700);
      spawn({ kind: 'spark', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, drag: 4, life: rand(0.15, 0.3), size: rand(1.2, 2.4), color: '#fff3c4' });
    }
    whipCrackSound();
    hitElement(x, y, 1, { x: x - A.x, y: y - A.y });
  }

  // ---------- Pedra ----------
  function stoneHand() {
    return { x: VW * 0.5 + (state.x - VW * 0.5) * 0.35, y: VH - 30 };
  }

  function drawStoneHand(now) {
    if (now < state.stoneReadyAt) return;
    const h = stoneHand();
    drawStone(ctx, h.x, h.y, 30, 0, state.stoneShape);
  }

  function throwStone() {
    const now = performance.now();
    if (now < state.stoneReadyAt) return;
    state.stoneReadyAt = now + 220;
    const s = stoneHand();
    projectiles.push({ kind: 'stone', sx: s.x, sy: s.y, tx: state.x, ty: state.y, t0: now, dur: 420, h: 140, shape: state.stoneShape, spin: rand(-12, 12) });
    state.stoneShape = makeStoneShape();
    noise(0.25, 'bandpass', 500, 0.25, 1500, 1);
  }

  function impactStone(x, y) {
    addMark(drawGlassCrack(), x, y);
    for (let i = 0; i < 10; i++) {
      const shade = 90 + Math.random() * 60 | 0;
      spawn({ kind: 'chunk', x, y, vx: rand(-320, 320), vy: rand(-520, -120), g: 1500, life: rand(0.6, 1.1), size: rand(3, 7), vr: rand(-15, 15), color: `rgb(${shade},${shade - 4},${shade - 10})` });
    }
    for (let i = 0; i < 14; i++) {
      spawn({ kind: 'chunk', x, y, vx: rand(-420, 420), vy: rand(-480, -60), g: 1300, life: rand(0.5, 0.9), size: rand(2, 4), vr: rand(-20, 20), color: 'rgba(225,240,255,.9)' });
    }
    for (let i = 0; i < 7; i++) {
      spawn({ kind: 'dust', x: x + rand(-10, 10), y: y + rand(-10, 10), vx: rand(-40, 40), vy: rand(-50, -10), life: rand(0.5, 0.8), size: rand(10, 20), color: '#9a948a' });
    }
    stoneSound();
    hitElement(x, y, 2, { x: 0, y: -1 });
  }

  function makeStoneShape() {
    const n = 11, radii = [];
    for (let i = 0; i < n; i++) radii.push(rand(0.75, 1.1));
    return { radii, tone: rand(-15, 15) };
  }

  function drawStone(g, x, y, r, rot, shape) {
    g.save();
    g.translate(x, y);
    g.rotate(rot);
    g.beginPath();
    shape.radii.forEach((k, i) => {
      const a = (i / shape.radii.length) * Math.PI * 2;
      const px = Math.cos(a) * r * k, py = Math.sin(a) * r * k * 0.85;
      i ? g.lineTo(px, py) : g.moveTo(px, py);
    });
    g.closePath();
    const c = 140 + shape.tone;
    const grd = g.createRadialGradient(-r * 0.35, -r * 0.35, r * 0.1, 0, 0, r * 1.1);
    grd.addColorStop(0, `rgb(${c + 40},${c + 36},${c + 30})`);
    grd.addColorStop(1, `rgb(${c - 70},${c - 72},${c - 76})`);
    g.fillStyle = grd;
    g.fill();
    g.strokeStyle = 'rgba(0,0,0,.55)';
    g.lineWidth = 1.5;
    g.stroke();
    g.fillStyle = 'rgba(0,0,0,.18)';
    g.beginPath(); g.arc(r * 0.25, r * 0.2, r * 0.12, 0, 7); g.fill();
    g.beginPath(); g.arc(-r * 0.3, r * 0.3, r * 0.08, 0, 7); g.fill();
    g.restore();
  }

  // ---------- Arma ----------
  function drawGun() {
    const px = VW * 0.76 + (state.x - VW / 2) * 0.08, py = VH + 40;
    const a = Math.atan2(state.y - py, state.x - px);
    const back = state.recoil * 22;
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(a);
    ctx.translate(-back, 0);
    ctx.fillStyle = '#18191c';
    ctx.beginPath();
    ctx.moveTo(70, 6); ctx.lineTo(112, 6); ctx.lineTo(92, 80); ctx.lineTo(54, 74);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#2c2f35';
    ctx.beginPath(); ctx.roundRect(50, -20, 190, 30, 6); ctx.fill();
    ctx.fillStyle = '#4a4f57';
    ctx.beginPath(); ctx.roundRect(50, -20, 190, 9, [6, 6, 0, 0]); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.45)';
    ctx.lineWidth = 2;
    for (let i = 0; i < 6; i++) {
      ctx.beginPath(); ctx.moveTo(62 + i * 7, -18); ctx.lineTo(62 + i * 7, 6); ctx.stroke();
    }
    ctx.fillStyle = '#0d0e10';
    ctx.fillRect(236, -14, 10, 18);
    ctx.fillStyle = '#e8433a';
    ctx.fillRect(228, -25, 6, 6);
    ctx.restore();

    const rot = (lx, ly) => ({ x: px + Math.cos(a) * lx - Math.sin(a) * ly, y: py + Math.sin(a) * lx + Math.cos(a) * ly });
    state.muzzle = rot(246 - back, -5);
    state.eject = rot(120 - back, -20);
  }

  function shoot() {
    const spread = state.recoil * 14;
    const tx = state.x + rand(-spread, spread), ty = state.y + rand(-spread, spread);
    state.recoil = Math.min(1, state.recoil + 0.6);
    const m = state.muzzle;

    spawn({ kind: 'flash', x: m.x, y: m.y, life: 0.06, size: 48 });
    spawn({ kind: 'tracer', x: m.x, y: m.y, x2: tx, y2: ty, life: 0.05 });
    spawn({ kind: 'shell', x: state.eject.x, y: state.eject.y, vx: rand(120, 300), vy: rand(-520, -380), g: 1600, life: 1.2, vr: rand(-20, 20), size: 1 });
    spawn({ kind: 'flash', x: tx, y: ty, life: 0.05, size: 22 });
    for (let i = 0; i < 9; i++) {
      const a = rand(0, Math.PI * 2), v = rand(200, 600);
      spawn({ kind: 'spark', x: tx, y: ty, vx: Math.cos(a) * v, vy: Math.sin(a) * v, drag: 5, g: 600, life: rand(0.12, 0.3), size: rand(1.2, 2.2), color: '#ffcf5a' });
    }
    for (let i = 0; i < 3; i++) {
      spawn({ kind: 'dust', x: tx, y: ty, vx: rand(-30, 30), vy: rand(-40, 0), life: rand(0.4, 0.7), size: rand(6, 12), color: '#8f8a82' });
    }
    addMark(drawBulletHole(), tx, ty);
    bangSound();
    hitElement(tx, ty, 1, { x: tx - m.x, y: ty - m.y });
  }

  // ---------- Arco e flecha ----------
  function bowPivot() {
    return { x: VW * 0.5 + (state.x - VW * 0.5) * 0.2, y: VH - 10 };
  }

  function drawBow(now) {
    const P = bowPivot();
    const a = Math.atan2(state.y - P.y, state.x - P.x);
    const charge = state.chargeStart ? clamp((now - state.chargeStart) / CHARGE_MS, 0, 1) : 0;
    const pull = charge * 48;
    const nockX = 30 - pull;
    const shake = charge >= 1 ? rand(-0.6, 0.6) : 0;

    ctx.save();
    ctx.translate(P.x + shake, P.y + shake);
    ctx.rotate(a);
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#3b2410';
    ctx.lineWidth = 9;
    ctx.beginPath(); ctx.moveTo(30, -95); ctx.quadraticCurveTo(110 - pull * 0.3, 0, 30, 95); ctx.stroke();
    ctx.strokeStyle = '#8a5a2b';
    ctx.lineWidth = 5;
    ctx.beginPath(); ctx.moveTo(30, -95); ctx.quadraticCurveTo(110 - pull * 0.3, 0, 30, 95); ctx.stroke();
    ctx.strokeStyle = '#1d140c';
    ctx.lineWidth = 11;
    ctx.beginPath(); ctx.moveTo(68 - pull * 0.15, -14); ctx.lineTo(68 - pull * 0.15, 14); ctx.stroke();
    ctx.strokeStyle = 'rgba(240,240,230,.9)';
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(30, -95); ctx.lineTo(nockX, 0); ctx.lineTo(30, 95); ctx.stroke();
    if (now >= state.arrowReadyAt) {
      ctx.save();
      ctx.translate(nockX, 0);
      drawArrowLocal(ctx, 125);
      ctx.restore();
    }
    ctx.restore();

    const tipX = nockX + 125;
    state.bowTip = { x: P.x + Math.cos(a) * tipX, y: P.y + Math.sin(a) * tipX };
  }

  function drawArrowLocal(g, len) {
    g.lineCap = 'round';
    g.strokeStyle = '#3d2410';
    g.lineWidth = 4.5;
    g.beginPath(); g.moveTo(6, 0); g.lineTo(len - 14, 0); g.stroke();
    g.strokeStyle = '#b07f4c';
    g.lineWidth = 2.4;
    g.beginPath(); g.moveTo(6, 0); g.lineTo(len - 14, 0); g.stroke();
    g.fillStyle = '#9aa3ad';
    g.strokeStyle = '#4b5560';
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(len, 0); g.lineTo(len - 18, -6); g.lineTo(len - 14, 0); g.lineTo(len - 18, 6);
    g.closePath(); g.fill(); g.stroke();
    g.fillStyle = '#d8392b';
    for (const s of [-1, 1]) {
      g.beginPath();
      g.moveTo(32, 0); g.lineTo(12, 9 * s); g.lineTo(-1, 9 * s); g.lineTo(7, 0);
      g.closePath(); g.fill();
    }
    g.fillStyle = '#222';
    g.fillRect(0, -2, 5, 4);
  }

  function fireArrow() {
    const now = performance.now();
    if (now < state.arrowReadyAt) return;
    const power = clamp((now - state.chargeStart) / CHARGE_MS, 0.15, 1);
    const s = state.bowTip;
    const dist = Math.hypot(state.x - s.x, state.y - s.y);
    projectiles.push({
      kind: 'arrow', sx: s.x, sy: s.y, tx: state.x, ty: state.y, t0: now,
      dur: clamp((dist / (900 + power * 1600)) * 1000, 120, 700),
      h: (1 - power) * 120 + 10, power, ang: 0
    });
    state.arrowReadyAt = now + 350;
    twangSound(power);
  }

  function impactArrow(x, y, ang, power) {
    const mark = drawArrowStuck(ang, power);
    addMark(mark, x, y);
    mark.animate(
      [{ transform: 'rotate(0deg)' }, { transform: 'rotate(5deg)' }, { transform: 'rotate(-4deg)' }, { transform: 'rotate(2.5deg)' }, { transform: 'rotate(-1deg)' }, { transform: 'rotate(0deg)' }],
      { duration: 650, easing: 'ease-out' }
    );
    for (let i = 0; i < 7; i++) {
      spawn({ kind: 'chunk', x, y, vx: rand(-260, 260), vy: rand(-420, -80), g: 1400, life: rand(0.5, 0.9), size: rand(2, 4), vr: rand(-20, 20), color: '#a0784a' });
    }
    thwackSound();
    hitElement(x, y, 1 + power * 2, { x: Math.cos(ang), y: Math.sin(ang) });
  }

  // ---------- Projéteis ----------
  function updateProjectiles(now) {
    for (let i = projectiles.length - 1; i >= 0; i--) {
      const p = projectiles[i];
      const t = Math.min(1, (now - p.t0) / p.dur);
      const x = lerp(p.sx, p.tx, t);
      const y = lerp(p.sy, p.ty, t) - p.h * 4 * t * (1 - t);
      if (p.kind === 'stone') {
        drawStone(ctx, x, y, lerp(30, 13, t), p.spin * t, p.shape);
      } else {
        p.ang = Math.atan2((p.ty - p.sy) - p.h * 4 * (1 - 2 * t), p.tx - p.sx);
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(p.ang);
        const sc = lerp(1, 0.8, t);
        ctx.scale(sc, sc);
        ctx.translate(-125, 0);
        drawArrowLocal(ctx, 125);
        ctx.restore();
      }
      if (t >= 1) {
        projectiles.splice(i, 1);
        if (p.kind === 'stone') impactStone(p.tx, p.ty);
        else impactArrow(p.tx, p.ty, p.ang, p.power);
      }
    }
  }

  // ---------- Partículas ----------
  function spawn(p) {
    if (particles.length >= MAX_PARTICLES) particles.shift();
    const q = Object.assign({ vx: 0, vy: 0, g: 0, drag: 0, rot: rand(0, 6), vr: 0, size: 3, color: '#fff' }, p);
    q.max = q.life;
    particles.push(q);
  }

  function updateParticles(dt) {
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.life -= dt;
      if (p.life <= 0) { particles.splice(i, 1); continue; }
      p.vx *= 1 - Math.min(1, p.drag * dt);
      p.vy *= 1 - Math.min(1, p.drag * dt);
      p.vy += p.g * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
      const k = p.life / p.max;
      ctx.globalAlpha = k;

      switch (p.kind) {
        case 'spark':
          ctx.strokeStyle = p.color;
          ctx.lineWidth = p.size;
          ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * 0.03, p.y - p.vy * 0.03); ctx.stroke();
          break;
        case 'chunk':
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          ctx.fillStyle = p.color; ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.7);
          ctx.restore();
          break;
        case 'dust':
          ctx.globalAlpha = k * 0.35;
          ctx.fillStyle = p.color;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1 + (1 - k) * 2), 0, 7); ctx.fill();
          break;
        case 'flash': {
          const r = p.size * (0.6 + 0.4 * k);
          const grd = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
          grd.addColorStop(0, 'rgba(255,255,230,1)');
          grd.addColorStop(0.3, 'rgba(255,200,80,.9)');
          grd.addColorStop(1, 'rgba(255,120,0,0)');
          ctx.fillStyle = grd;
          ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fill();
          break;
        }
        case 'tracer':
          ctx.strokeStyle = 'rgba(255,230,150,.9)';
          ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x2, p.y2); ctx.stroke();
          break;
        case 'shell':
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          ctx.fillStyle = '#d4a63a'; ctx.fillRect(-5, -2.2, 10, 4.4);
          ctx.fillStyle = '#8a6a1e'; ctx.fillRect(3, -2.2, 2, 4.4);
          ctx.restore();
          break;
      }
    }
    ctx.globalAlpha = 1;
  }

  // ---------- Mira ----------
  function drawCrosshair(now) {
    const w = state.weapon;
    const col = w === 'arma' ? '#ff3b30' : w === 'arco' ? '#ffd60a' : '#ffffff';
    const gap = w === 'arma' ? 6 + state.recoil * 16 : 7;
    const len = 9;
    ctx.save();
    ctx.translate(state.x, state.y);
    ctx.lineCap = 'round';
    const both = (fn) => {
      ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 4; fn();
      ctx.strokeStyle = col; ctx.lineWidth = 2; fn();
    };
    both(() => {
      ctx.beginPath();
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        ctx.moveTo(dx * gap, dy * gap);
        ctx.lineTo(dx * (gap + len), dy * (gap + len));
      }
      ctx.stroke();
    });
    if (w === 'arco' && state.chargeStart) {
      const c = clamp((now - state.chargeStart) / CHARGE_MS, 0, 1);
      both(() => { ctx.beginPath(); ctx.arc(0, 0, 24, -Math.PI / 2, -Math.PI / 2 + c * Math.PI * 2); ctx.stroke(); });
    }
    ctx.fillStyle = col;
    ctx.beginPath(); ctx.arc(0, 0, 1.8, 0, 7); ctx.fill();
    ctx.restore();
  }

  // ---------- Marcas na página ----------
  function makeCanvas(S) {
    const c = document.createElement('canvas');
    c.width = Math.round(S * dpr);
    c.height = Math.round(S * dpr);
    c._size = S;
    const g = c.getContext('2d');
    g.scale(dpr, dpr);
    return [c, g];
  }

  function addMark(c, x, y) {
    const S = c._size;
    c._px = x + scrollX;
    c._py = y + scrollY;
    c.style.cssText = `all:initial;position:absolute;left:${c._px - S / 2}px;top:${c._py - S / 2}px;width:${S}px;height:${S}px;pointer-events:none;`;
    marksLayer.appendChild(c);
    marks.push(c);
    if (marks.length > MAX_MARKS) marks.shift().remove();
  }

  function crackPath(x, y, a, L, steps) {
    const pts = [[x, y]];
    let cx = x, cy = y;
    for (let i = 1; i <= steps; i++) {
      const aa = a + (Math.random() - 0.5) * 0.7;
      cx += Math.cos(aa) * (L / steps);
      cy += Math.sin(aa) * (L / steps);
      pts.push([cx, cy]);
    }
    return pts;
  }

  function strokePts(g, pts, w, color) {
    g.strokeStyle = color;
    g.lineWidth = w;
    g.beginPath();
    g.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]);
    g.stroke();
  }

  function strokeCrack(g, pts, w) {
    strokePts(g, pts, w + 1.4, 'rgba(0,0,0,.45)');
    strokePts(g, pts, w, 'rgba(255,255,255,.85)');
  }

  function drawBulletHole() {
    const S = 70, [c, g] = makeCanvas(S), m = S / 2;
    g.lineCap = 'round';
    g.lineJoin = 'round';
    const n = 6 + (Math.random() * 4 | 0);
    for (let i = 0; i < n; i++) {
      strokeCrack(g, crackPath(m, m, rand(0, Math.PI * 2), rand(12, 30), 4), 0.8);
    }
    const grd = g.createRadialGradient(m, m, 2, m, m, 13);
    grd.addColorStop(0, 'rgba(0,0,0,.95)');
    grd.addColorStop(0.45, 'rgba(40,40,40,.8)');
    grd.addColorStop(0.7, 'rgba(170,170,170,.45)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.beginPath(); g.arc(m, m, 13, 0, 7); g.fill();
    g.fillStyle = '#050505';
    g.beginPath(); g.arc(m, m, 4.2, 0, 7); g.fill();
    return c;
  }

  function drawGlassCrack() {
    const S = 300, [c, g] = makeCanvas(S), m = S / 2;
    g.lineCap = 'round';
    g.lineJoin = 'round';
    const n = 9 + (Math.random() * 6 | 0);
    const rays = [];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + rand(-0.25, 0.25);
      rays.push(crackPath(m, m, a, rand(60, m - 8), 7));
    }
    for (const r of rays) strokeCrack(g, r, 1.1);
    for (const k of [2, 4, 6]) {
      for (let i = 0; i < n; i++) {
        if (Math.random() < 0.35) continue;
        const p1 = rays[i][k], p2 = rays[(i + 1) % n][k];
        const mid = [(p1[0] + p2[0]) / 2 + rand(-6, 6), (p1[1] + p2[1]) / 2 + rand(-6, 6)];
        strokeCrack(g, [p1, mid, p2], 0.8);
      }
    }
    const grd = g.createRadialGradient(m, m, 0, m, m, 18);
    grd.addColorStop(0, 'rgba(255,255,255,.9)');
    grd.addColorStop(0.5, 'rgba(200,215,230,.5)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.beginPath(); g.arc(m, m, 18, 0, 7); g.fill();
    g.strokeStyle = 'rgba(0,0,0,.4)';
    g.lineWidth = 1;
    g.beginPath(); g.arc(m, m, rand(5, 8), 0, 7); g.stroke();
    return c;
  }

  function drawWelt(angle) {
    const S = 240, [c, g] = makeCanvas(S), m = S / 2;
    const len = rand(75, 105), bend = rand(-18, -8);
    g.translate(m, m);
    g.rotate(angle);
    g.lineCap = 'round';
    g.shadowColor = 'rgba(170,0,0,.6)';
    g.shadowBlur = 9;
    g.strokeStyle = 'rgba(140,10,10,.75)';
    g.lineWidth = 8;
    g.beginPath(); g.moveTo(-len, 5); g.quadraticCurveTo(0, bend, len, 3); g.stroke();
    g.shadowBlur = 0;
    g.strokeStyle = 'rgba(255,95,95,.85)';
    g.lineWidth = 2.5;
    g.beginPath(); g.moveTo(-len * 0.9, 3); g.quadraticCurveTo(0, bend - 2, len * 0.9, 1); g.stroke();
    g.fillStyle = 'rgba(110,0,0,.7)';
    for (let i = 0; i < 10; i++) {
      const s = rand(-1, 1);
      g.beginPath(); g.arc(s * len, bend * (1 - s * s) + rand(-6, 6), rand(0.8, 2), 0, 7); g.fill();
    }
    return c;
  }

  function drawArrowStuck(ang, power) {
    const S = 280, [c, g] = makeCanvas(S), m = S / 2;
    const embed = 18 + power * 22;
    g.translate(m, m);
    g.rotate(ang);
    g.fillStyle = 'rgba(0,0,0,.25)';
    g.beginPath(); g.ellipse(-60 + embed / 2, 7, 60, 3, 0, 0, 7); g.fill();
    g.save();
    g.beginPath(); g.rect(-200, -40, 200, 80); g.clip();
    g.translate(-125 + embed, 0);
    drawArrowLocal(g, 125);
    g.restore();
    g.fillStyle = 'rgba(0,0,0,.75)';
    g.beginPath(); g.arc(0, 0, 3.5, 0, 7); g.fill();
    return c;
  }

  // ---------- Reação dos elementos ----------
  function targetAt(x, y) {
    fx.style.pointerEvents = 'none';
    hudHost.style.pointerEvents = 'none';
    let el = document.elementFromPoint(x, y);
    fx.style.pointerEvents = '';
    hudHost.style.pointerEvents = '';
    while (el && el !== document.body && el !== document.documentElement) {
      const cs = getComputedStyle(el);
      if (cs.display !== 'inline' && cs.display !== 'contents') {
        const r = el.getBoundingClientRect();
        return r.width * r.height < VW * VH * 0.5 ? el : null;
      }
      el = el.parentElement;
    }
    return null;
  }

  function hitElement(x, y, power, dir) {
    state.hits++;
    updateHud();
    const el = targetAt(x, y);
    if (!el) return;

    let d = damaged.get(el);
    if (!d) {
      const r = el.getBoundingClientRect();
      d = { hp: Math.max(2, Math.round(Math.sqrt(r.width * r.height) / 40)), tilt: 0, fallen: false };
      damaged.set(el, d);
    }
    if (d.fallen) return;

    const mag = 4 + power * 4;
    const n = Math.hypot(dir.x, dir.y) || 1;
    const ux = (dir.x / n) * mag, uy = (dir.y / n) * mag;
    el.animate(
      [
        { transform: 'translate(0px,0px) rotate(0deg)' },
        { transform: `translate(${ux + rand(-mag, mag) * 0.4}px,${uy + rand(-mag, mag) * 0.4}px) rotate(${rand(-2, 2) * power}deg)` },
        { transform: `translate(${-ux * 0.5}px,${-uy * 0.5}px) rotate(${rand(-1, 1)}deg)` },
        { transform: 'translate(0px,0px) rotate(0deg)' }
      ],
      { duration: 260, easing: 'ease-out', composite: 'add' }
    );

    const prev = d.tilt;
    d.tilt = clamp(d.tilt + rand(-1.6, 1.6) * power, -9, 9);
    d.tiltAnim?.cancel();
    d.tiltAnim = el.animate(
      [{ transform: `rotate(${prev}deg)` }, { transform: `rotate(${d.tilt}deg)` }],
      { duration: 160, fill: 'forwards', composite: 'add' }
    );

    d.hp -= power;
    if (d.hp <= 0) fall(el, d, dir);
  }

  function fall(el, d, dir) {
    d.fallen = true;
    const r = el.getBoundingClientRect();
    const dx = (dir.x >= 0 ? 1 : -1) * rand(40, 160);
    const rot = rand(-35, 35);
    const drop = VH - r.top + 250;
    d.fallAnim = el.animate(
      [
        { transform: 'translate(0px,0px) rotate(0deg)' },
        { transform: `translate(${dx * 0.1}px,8px) rotate(${rot * 0.25}deg)`, offset: 0.18 },
        { transform: `translate(${dx}px,${drop}px) rotate(${rot}deg)` }
      ],
      { duration: 1300, delay: 120, easing: 'cubic-bezier(.55,0,.9,.45)', fill: 'forwards', composite: 'add' }
    );
    for (let i = 0; i < 14; i++) {
      spawn({ kind: 'dust', x: rand(r.left, r.right), y: r.bottom, vx: rand(-60, 60), vy: rand(-60, -10), life: rand(0.6, 1), size: rand(10, 22), color: '#a39d93' });
    }
    tone(0.6, 'sine', 1300, 260, 0.07, 0.1);
    const L = r.left + scrollX, T = r.top + scrollY;
    for (let i = marks.length - 1; i >= 0; i--) {
      const m = marks[i];
      if (m._px >= L && m._px <= L + r.width && m._py >= T && m._py <= T + r.height) {
        m.remove();
        marks.splice(i, 1);
      }
    }
  }

  // ---------- Som (gerado com Web Audio, sem arquivos) ----------
  let ac = null, master = null, noiseBuf = null;

  function audio() {
    if (!state.sound) return null;
    try {
      if (!ac) {
        ac = new (window.AudioContext || window.webkitAudioContext)();
        master = ac.createGain();
        master.gain.value = 0.5;
        master.connect(ac.destination);
        const len = ac.sampleRate;
        noiseBuf = ac.createBuffer(1, len, ac.sampleRate);
        const data = noiseBuf.getChannelData(0);
        for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      }
      if (ac.state === 'suspended') ac.resume();
      return ac;
    } catch {
      return null;
    }
  }

  function noise(dur, type, freq, vol, freqEnd, q = 1, delay = 0) {
    const a = audio();
    if (!a) return;
    const t = a.currentTime + delay;
    const src = a.createBufferSource();
    src.buffer = noiseBuf;
    const f = a.createBiquadFilter();
    f.type = type;
    f.Q.value = q;
    f.frequency.setValueAtTime(freq, t);
    if (freqEnd) f.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    const g = a.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f).connect(g).connect(master);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.02);
  }

  function tone(dur, type, f0, f1, vol, delay = 0) {
    const a = audio();
    if (!a) return;
    const t = a.currentTime + delay;
    const o = a.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    const g = a.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  function whipCrackSound() {
    noise(0.06, 'highpass', 2500, 1);
    tone(0.035, 'square', 1800, 500, 0.2);
    noise(0.12, 'bandpass', 900, 0.3, 300, 1, 0.02);
  }

  function bangSound() {
    noise(0.35, 'lowpass', 4000, 1, 200);
    tone(0.18, 'sine', 150, 40, 0.8);
    noise(0.04, 'highpass', 3000, 0.5);
  }

  function stoneSound() {
    tone(0.18, 'sine', 120, 45, 0.9);
    noise(0.12, 'lowpass', 900, 0.6);
    for (let i = 0; i < 5; i++) {
      const f = rand(2500, 6000);
      tone(rand(0.12, 0.3), 'sine', f, f * 0.92, 0.07, i * 0.02 + rand(0, 0.05));
    }
    noise(0.25, 'highpass', 4000, 0.25);
  }

  function twangSound(power) {
    tone(0.28, 'triangle', 180 + power * 40, 160, 0.35);
    noise(0.14, 'bandpass', 700, 0.2, 3000, 1);
  }

  function thwackSound() {
    tone(0.12, 'sine', 240, 70, 0.7);
    noise(0.06, 'bandpass', 1500, 0.6);
  }

  // ---------- Barra de ferramentas na página ----------
  const SPEAKER_ON = '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/><path d="M19 6a8.5 8.5 0 0 1 0 12"/></svg>';
  const SPEAKER_OFF = '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M17 9l5 6M22 9l-5 6"/></svg>';

  function buildHud() {
    hudHost = document.createElement('div');
    hudHost.setAttribute('data-destruidor', 'hud');
    hudHost.style.cssText = `all:initial;position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:${Z + 2};display:none;`;
    hudRoot = hudHost.attachShadow({ mode: 'open' });
    hudRoot.innerHTML = `
      <style>
        :host { all: initial; }
        .bar { display:flex; align-items:center; gap:4px; padding:6px; border-radius:16px;
          background:rgba(18,18,22,.9); backdrop-filter:blur(10px); border:1px solid rgba(255,255,255,.1);
          box-shadow:0 10px 30px rgba(0,0,0,.35); font:500 12px/1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
          color:#e9e9ee; user-select:none; }
        button { all:unset; box-sizing:border-box; cursor:pointer; display:flex; align-items:center; justify-content:center;
          border-radius:11px; color:#c9c9d1; transition:background .12s,color .12s,transform .08s; }
        button:hover { background:rgba(255,255,255,.08); color:#fff; }
        button:active { transform:scale(.94); }
        .w { width:44px; height:44px; position:relative; }
        .w.on { background:#ff4d2e; color:#fff; box-shadow:0 4px 14px rgba(255,77,46,.45); }
        .w .k { position:absolute; right:4px; bottom:3px; font-size:9px; opacity:.7; }
        svg { width:22px; height:22px; fill:none; stroke:currentColor; stroke-width:1.8; stroke-linecap:round; stroke-linejoin:round; }
        .sep { width:1px; height:28px; background:rgba(255,255,255,.12); margin:0 4px; }
        .hits { display:flex; flex-direction:column; align-items:center; gap:3px; min-width:52px; padding:0 4px; }
        .hits b { font-size:16px; font-weight:700; color:#fff; font-variant-numeric:tabular-nums; }
        .hits span { font-size:10px; opacity:.6; text-transform:uppercase; letter-spacing:.06em; }
        .a { height:44px; padding:0 12px; gap:6px; }
        .a.icon { width:44px; padding:0; }
        .x:hover { background:rgba(255,77,46,.18); color:#ff7a5f; }
        .nome { padding:0 8px 0 4px; font-weight:600; min-width:96px; }
      </style>
      <div class="bar">
        ${ORDER.map((w, i) => `<button class="w" data-w="${w}" title="${NAMES[w]} (tecla ${i + 1})">${ICONS[w]}<span class="k">${i + 1}</span></button>`).join('')}
        <span class="nome" id="nome"></span>
        <div class="sep"></div>
        <div class="hits"><b id="hits">0</b><span>golpes</span></div>
        <div class="sep"></div>
        <button class="a icon" id="som" title="Ligar ou desligar o som"></button>
        <button class="a" id="limpar" title="Remover todas as marcas">Limpar</button>
        <button class="a icon x" id="sair" title="Sair (Esc)"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
      </div>`;

    hudRoot.querySelectorAll('.w').forEach((b) => b.addEventListener('click', () => setWeapon(b.dataset.w)));
    hudRoot.getElementById('som').addEventListener('click', () => {
      state.sound = !state.sound;
      try { chrome.storage.local.set({ sound: state.sound }).catch(() => {}); } catch {}
      updateHud();
    });
    hudRoot.getElementById('limpar').addEventListener('click', reset);
    hudRoot.getElementById('sair').addEventListener('click', deactivate);
  }

  function updateHud() {
    if (!hudRoot) return;
    hudRoot.querySelectorAll('.w').forEach((b) => b.classList.toggle('on', b.dataset.w === state.weapon));
    hudRoot.getElementById('nome').textContent = NAMES[state.weapon];
    hudRoot.getElementById('hits').textContent = state.hits;
    hudRoot.getElementById('som').innerHTML = state.sound ? SPEAKER_ON : SPEAKER_OFF;
  }

  // ---------- Mensagens do popup e do atalho ----------
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    switch (msg?.type) {
      case 'activate': activate(msg.weapon); break;
      case 'deactivate': deactivate(); break;
      case 'toggle': state.active ? deactivate() : activate(msg.weapon); break;
      case 'setWeapon': setWeapon(msg.weapon); break;
      case 'reset': reset(); break;
    }
    reply({ active: state.active, weapon: state.weapon, hits: state.hits });
  });
})();
