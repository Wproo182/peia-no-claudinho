const ARMAS = [
  { id: 'chicote', nome: 'Chicote', desc: 'Estalos que deixam vergões e sacodem tudo',
    icon: '<svg viewBox="0 0 24 24"><path d="M3 21l4.5-5"/><path d="M7.5 16c3-4 9.5-2 11.5-6.5S17 2 13 4.5"/></svg>' },
  { id: 'pedra', nome: 'Pedra', desc: 'Arremesso que trinca a tela como vidro',
    icon: '<svg viewBox="0 0 24 24"><path d="M4 15l2.5-6.5L13 5l6 3.5L21 15l-5 4.5H8.5z"/><path d="M9 11l3 2 3.5-1"/></svg>' },
  { id: 'arma', nome: 'Arma', desc: 'Segure o clique para rajada automática',
    icon: '<svg viewBox="0 0 24 24"><path d="M2.5 7.5h18v4.5h-9l-1 2.5H8l-1.2 5H3.5l1.2-7.5H2.5z"/><path d="M20.5 7.5V6"/></svg>' },
  { id: 'arco', nome: 'Arco e flecha', desc: 'Segure para tensionar, solte para atirar',
    icon: '<svg viewBox="0 0 24 24"><path d="M6 2.5c9.5 3.5 9.5 15.5 0 19"/><path d="M6 2.5v19"/><path d="M3 12h18"/><path d="M18 9l3 3-3 3"/></svg>' }
];

const $ = (s) => document.querySelector(s);
let tabId = null;
let arma = 'chicote';
let ativo = false;

async function enviar(msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg);
  } catch {
    return null;
  }
}

async function garantirScript() {
  if (await enviar({ type: 'status' })) return true;
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    return true;
  } catch {
    const erro = $('#erro');
    erro.textContent = 'O Chrome não deixa extensões agirem nesta página (chrome://, Web Store e afins). Abra um site comum e tente de novo.';
    erro.hidden = false;
    return false;
  }
}

function render() {
  $('#grid').innerHTML = ARMAS.map((a, i) => `
    <button class="arma ${a.id === arma ? 'on' : ''}" data-id="${a.id}">
      <span class="topo">${a.icon}<span class="tecla">${i + 1}</span></span>
      <b>${a.nome}</b>
      <small>${a.desc}</small>
    </button>`).join('');

  document.querySelectorAll('.arma').forEach((b) => {
    b.addEventListener('click', async () => {
      arma = b.dataset.id;
      chrome.storage.local.set({ weapon: arma });
      render();
      if (ativo) {
        await enviar({ type: 'setWeapon', weapon: arma });
        window.close();
      }
    });
  });

  const btn = $('#toggle');
  btn.textContent = ativo ? 'Desativar nesta página' : 'Ativar nesta página';
  btn.classList.toggle('desligar', ativo);
}

$('#toggle').addEventListener('click', async () => {
  if (!(await garantirScript())) return;
  const r = await enviar({ type: ativo ? 'deactivate' : 'activate', weapon: arma });
  ativo = !!r?.active;
  render();
  if (ativo) window.close();
});

$('#limpar').addEventListener('click', async () => {
  if (await enviar({ type: 'status' })) await enviar({ type: 'reset' });
});

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab?.id;
  const salvo = await chrome.storage.local.get('weapon');
  if (salvo.weapon) arma = salvo.weapon;
  const status = await enviar({ type: 'status' });
  if (status) {
    ativo = status.active;
    arma = status.weapon;
  }
  render();
})();
