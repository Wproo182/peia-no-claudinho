# Peia no Claudinho

Extensão para Google Chrome (Manifest V3) que transforma qualquer site em alvo: chicote, pedras, arma e arco e flecha, com marcas, partículas, elementos que tremem, entortam e despencam, e sons gerados em tempo real.

## Instalação

1. Descompacte o arquivo `peia-no-claudinho.zip`.
2. Abra `chrome://extensions` e ative o **Modo do desenvolvedor**.
3. Clique em **Carregar sem compactação** e selecione a pasta.
4. Fixe o ícone na barra do Chrome.

## Como usar

- Clique no ícone, escolha a arma e toque em **Ativar nesta página**.
- Ou use o atalho **Alt+Shift+D** em qualquer aba.
- Teclas **1 a 4** trocam a arma, **Esc** sai.
- A barra no topo da página mostra o contador de golpes, liga e desliga o som e limpa os estragos.

| Arma | Como funciona | Efeito |
|---|---|---|
| Chicote | Clique | Estalo, faíscas e vergão vermelho |
| Pedra | Clique | Arremesso em arco, vidro trincado e estilhaços |
| Arma | Clique ou segure (rajada) | Clarão, buraco de bala, cápsulas voando, recuo |
| Arco e flecha | Segure para tensionar, solte | Flecha cravada que balança; quanto mais carga, mais reta e forte |

Cada elemento atingido treme e vai entortando. Depois de apanhar o suficiente, ele despenca da página. Recarregar a aba desfaz tudo.

## Estrutura

- `manifest.json`: permissões mínimas (`activeTab`, `scripting`, `storage`)
- `popup.html / popup.css / popup.js`: seleção de arma e ativação
- `content.js`: motor de efeitos (canvas, marcas, física, Web Audio)
- `background.js`: atalho de teclado

A extensão só roda na aba em que você ativar e não coleta nenhum dado.
