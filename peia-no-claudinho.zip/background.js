// Atalho de teclado (Alt+Shift+D): liga e desliga o modo destruição na aba atual
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'alternar') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'toggle' });
  } catch {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      const { weapon = 'chicote' } = await chrome.storage.local.get('weapon');
      await chrome.tabs.sendMessage(tab.id, { type: 'activate', weapon });
    } catch {
      // Páginas protegidas (chrome://, Chrome Web Store) não aceitam scripts
    }
  }
});
