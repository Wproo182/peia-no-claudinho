# Peia no Claudinho

Extensão para Google Chrome (Manifest V3) que transforma qualquer site em alvo. São 17 armas com animações, marcas na página, partículas, explosões, fogo, fumaça e sons gerados em tempo real. Os elementos atingidos tremem, entortam e despencam.

## Instalação

1. Extraia o arquivo `peia-no-claudinho.zip`.
2. Abra `chrome://extensions` e ative o **Modo do desenvolvedor**.
3. Clique em **Carregar sem compactação** e selecione a pasta que contém o `manifest.json`.
4. Fixe o ícone pelo quebra-cabeça da barra do Chrome.

Para atualizar uma versão já instalada, substitua os arquivos da pasta e clique no botão de recarregar do card da extensão em `chrome://extensions`. Depois recarregue as abas abertas.

## Como usar

- Clique no ícone, escolha a arma e toque em **Ativar nesta página**, ou use **Alt+Shift+D**.
- **Q** e **E** ou o **botão direito** do mouse trocam a arma. **Esc** sai.
- A barra no topo da página troca a arma, mostra os golpes, liga o som, limpa os estragos e pode ser recolhida.

## Arsenal

| Grupo | Arma | Como usar | Efeito |
|---|---|---|---|
| Corpo a corpo | Soco inglês | Clique ou segure | Amassado com marca dos dedos e balão POW |
| | Faca | Clique ou segure e arraste | Golpe rápido e cortes finos |
| | Facão | Clique ou segure e arraste | Golpe pesado e cortes largos |
| | Espada | Clique ou segure e arraste | Golpe longo em arco com faíscas |
| | Chicote | Clique | Estalo, faíscas e vergão vermelho |
| Arremesso | Pedra | Clique | Vidro trincado e estilhaços |
| | Estilingue | Segure e solte | Pedrinha rápida, mais forte com mais carga |
| | Granada | Clique | Cai, queima o pavio e explode |
| | Coquetel molotov | Clique | Garrafa quebra e a área pega fogo |
| | Bomba de fumaça | Clique | Nuvem de fumaça que cobre a tela |
| Disparo | Pistola | Clique | Tiro a tiro, preciso |
| | MP5 | Segure | Rajada muito rápida |
| | M4 | Segure | Rajada equilibrada |
| | AK-47 | Segure | Rajada pesada com muito coice |
| | Sniper | Clique | Luneta com mira que balança, tiro devastador |
| | Arco e flecha | Segure e solte | Flecha cravada que balança |
| | Bazuca | Clique | Foguete com rastro e explosão gigante |

Recarregar a aba desfaz tudo.

## Estrutura

- `manifest.json`: permissões mínimas (`activeTab`, `scripting`, `storage`)
- `weapons.js`: lista de armas compartilhada
- `popup.html / popup.css / popup.js`: seleção de arma e ativação
- `content.js`: motor de efeitos (canvas, marcas, física, Web Audio)
- `background.js`: atalho de teclado

A extensão só roda na aba em que você ativar e não coleta nenhum dado.
