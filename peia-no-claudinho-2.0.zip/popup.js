const ARMAS = self.PEIA_ARMAS || [];
const IDS = ARMAS.map((a) => a.id);
const SCRIPTS = ['weapons.js', 'content.js'];

const $ = (s) => document.querySelector(s);
let tabId = null;
let arma = IDS[0];
let ativo = false;

const normalizar = (w) => (w === 'arma' ? 'pistola' : IDS.includes(w) ? w : null);

async function enviar(msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg);
  } catch {
    return null;
  }
}

async function garantirScript() {
  if (await enviar({ type: 'status' })) return true;
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: SCRIPTS });
    return true;
  } catch {
    const erro = $('#erro');
    erro.textContent = 'O Chrome não deixa extensões agirem nesta página (chrome://, Web Store e afins). Abra um site comum e tente de novo.';
    erro.hidden = false;
    return false;
  }
}

function render() {
  const grupos = [...new Set(ARMAS.map((a) => a.grupo))];
  $('#grid').innerHTML = grupos.map((g) => `
    <h2>${g}</h2>
    <div class="linha">
      ${ARMAS.filter((a) => a.grupo === g).map((a) => `
        <button class="arma ${a.id === arma ? 'on' : ''}" data-id="${a.id}" title="${a.nome}">
          ${a.icon}<span>${a.curto}</span>
        </button>`).join('')}
    </div>`).join('');

  const atual = ARMAS.find((a) => a.id === arma) || ARMAS[0];
  $('#info').innerHTML = `${atual.icon}<div><b>${atual.nome}</b><small>${atual.desc}</small></div>`;

  document.querySelectorAll('.arma').forEach((b) => {
    b.addEventListener('click', async () => {
      arma = b.dataset.id;
      chrome.storage.local.set({ weapon: arma });
      render();
      if (ativo) await enviar({ type: 'setWeapon', weapon: arma });
    });
  });

  const btn = $('#toggle');
  btn.textContent = ativo ? 'Desativar nesta página' : 'Ativar nesta página';
  btn.classList.toggle('desligar', ativo);
}

$('#toggle').addEventListener('click', async () => {
  if (!(await garantirScript())) return;
  const r = await enviar({ type: ativo ? 'deactivate' : 'activate', weapon: arma });
  ativo = !!r?.active;
  render();
  if (ativo) window.close();
});

$('#limpar').addEventListener('click', async () => {
  if (await enviar({ type: 'status' })) await enviar({ type: 'reset' });
});

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab?.id;
  const salvo = await chrome.storage.local.get('weapon');
  arma = normalizar(salvo.weapon) || arma;
  const status = await enviar({ type: 'status' });
  if (status) {
    ativo = status.active;
    arma = normalizar(status.weapon) || arma;
  }
  render();
})();
