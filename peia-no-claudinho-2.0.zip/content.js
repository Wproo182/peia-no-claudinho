// Peia no Claudinho: motor de efeitos injetado na aba
(() => {
  if (window.__peiaNoClaudinho) return;
  window.__peiaNoClaudinho = true;

  const ARMAS = self.PEIA_ARMAS || [];
  const ORDER = ARMAS.map((a) => a.id);
  const INFO = Object.fromEntries(ARMAS.map((a) => [a.id, a]));
  const GROUPS = [...new Set(ARMAS.map((a) => a.grupo))];

  const TYPE = {
    soco: 'punch', faca: 'blade', facao: 'blade', espada: 'blade', chicote: 'whip',
    pedra: 'throw', estilingue: 'sling', granada: 'throw', molotov: 'throw', fumaca: 'throw',
    pistola: 'gun', mp5: 'gun', m4: 'gun', ak47: 'gun', sniper: 'gun', arco: 'bow', bazuca: 'bazooka'
  };

  const GUNS = {
    pistola: { tip: 246, my: -5, ej: 120, auto: 0, cd: 110, spread: 3, kick: 0.6, back: 22, dmg: 1, hole: 1, px: 0.76, py: 40 },
    mp5: { tip: 269, my: -7, ej: 150, auto: 70, spread: 10, kick: 0.3, back: 14, dmg: 0.8, hole: 0.85, px: 0.78, py: 50 },
    m4: { tip: 377, my: -7, ej: 170, auto: 88, spread: 7, kick: 0.35, back: 16, dmg: 1.1, hole: 1, px: 0.8, py: 70 },
    ak47: { tip: 360, my: -6.5, ej: 170, auto: 105, spread: 12, kick: 0.5, back: 20, dmg: 1.4, hole: 1.15, px: 0.8, py: 70 },
    sniper: { tip: 438, my: -8, ej: 150, auto: 0, cd: 1150, spread: 0, kick: 1, back: 40, dmg: 7, hole: 1.7, px: 0.82, py: 80 }
  };

  const BLADES = {
    faca: { len: 70, handle: 46, width: 10, cut: 2.6, slash: 80, power: 0.9, handleColor: '#2b2b2b', ring: 3600 },
    facao: { len: 125, handle: 50, width: 20, cut: 4.5, slash: 130, power: 1.8, handleColor: '#5a3418', ring: 2200, curved: true },
    espada: { len: 190, handle: 52, width: 12, cut: 3.6, slash: 190, power: 1.5, handleColor: '#3a1f12', ring: 2900, guard: true }
  };

  const THROWS = {
    pedra: { cd: 220, dur: 420, h: 140, proj: 'stone' },
    granada: { cd: 650, dur: 540, h: 170, proj: 'grenade' },
    molotov: { cd: 700, dur: 560, h: 160, proj: 'molotov' },
    fumaca: { cd: 750, dur: 540, h: 150, proj: 'smokecan' }
  };

  const Z = 2147483640;
  const LASH_MS = 380, CHARGE_MS = 900, SWING_MS = 170, PUNCH_MS = 230;
  const MAX_MARKS = 600, MAX_PARTICLES = 900;

  const rand = (a, b) => a + Math.random() * (b - a);
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const easeOut = (t) => 1 - (1 - t) * (1 - t);
  const easeIn = (t) => t * t;
  const dirOf = (a) => ({ x: Math.cos(a), y: Math.sin(a) });
  const angleDiff = (a, b) => Math.atan2(Math.sin(a - b), Math.cos(a - b));
  const normalize = (w) => (w === 'arma' ? 'pistola' : ORDER.includes(w) ? w : null);

  const state = {
    active: false,
    weapon: ORDER[0] || 'chicote',
    x: innerWidth / 2,
    y: innerHeight / 2,
    aim: { x: innerWidth / 2, y: innerHeight / 2 },
    down: false,
    chargeStart: 0,
    sound: true,
    hits: 0,
    recoil: 0,
    shake: 0,
    autoTimer: null,
    readyAt: {},
    handShape: makeStoneShape(),
    muzzle: { x: 0, y: 0 },
    eject: { x: 0, y: 0 },
    rear: { x: 0, y: 0 },
    bowTip: { x: 0, y: 0 },
    slingTip: { x: 0, y: 0 },
    blade: { ang: -2.3, lastX: 0, lastY: 0, lastHit: 0, lastSwish: 0, swing: null, side: 1 },
    punch: null,
    minimized: false
  };
  const ready = (w, now) => now >= (state.readyAt[w] || 0);

  let fx, ctx, marksLayer, hudHost, hudRoot;
  let dpr = 1, VW = innerWidth, VH = innerHeight;
  let raf = 0, last = 0, lash = null;
  const particles = [];
  const projectiles = [];
  const marks = [];
  const zones = [];
  const emitters = [];
  const bombs = [];
  const damaged = new Map();

  try {
    chrome.storage.local.get(['weapon', 'sound']).then((v) => {
      const w = normalize(v.weapon);
      if (w && !state.active) state.weapon = w;
      if (typeof v.sound === 'boolean') state.sound = v.sound;
      updateHud();
    }).catch(() => {});
  } catch {}

  // ---------- Estrutura ----------
  function build() {
    marksLayer = document.createElement('div');
    marksLayer.setAttribute('data-peia', 'marcas');
    marksLayer.style.cssText = `all:initial;position:absolute;left:0;top:0;width:0;height:0;overflow:visible;pointer-events:none;z-index:${Z};`;

    fx = document.createElement('canvas');
    fx.setAttribute('data-peia', 'efeitos');
    fx.style.cssText = `all:initial;position:fixed;left:0;top:0;width:100%;height:100%;z-index:${Z + 1};cursor:none;display:none;touch-action:none;`;
    ctx = fx.getContext('2d');

    buildHud();
    document.documentElement.append(marksLayer, fx, hudHost);
    resize();

    addEventListener('resize', resize);
    addEventListener('keydown', onKey, true);
    fx.addEventListener('pointerdown', onDown);
    fx.addEventListener('pointermove', onMove);
    fx.addEventListener('pointerup', onUp);
    fx.addEventListener('pointercancel', onUp);
    fx.addEventListener('contextmenu', (e) => { e.preventDefault(); cycle(1); });
  }

  function resize() {
    if (!fx) return;
    dpr = Math.min(devicePixelRatio || 1, 2);
    VW = document.documentElement.clientWidth || innerWidth;
    VH = document.documentElement.clientHeight || innerHeight;
    fx.width = Math.round(VW * dpr);
    fx.height = Math.round(VH * dpr);
  }

  function activate(weapon) {
    if (!fx) build();
    const w = normalize(weapon);
    if (w) setWeapon(w);
    state.active = true;
    fx.style.display = 'block';
    hudHost.style.display = 'block';
    updateHud();
    if (!raf) {
      last = performance.now();
      raf = requestAnimationFrame(loop);
    }
  }

  function deactivate() {
    state.active = false;
    stopInput();
    lash = null;
    projectiles.length = 0;
    particles.length = 0;
    zones.length = 0;
    emitters.length = 0;
    bombs.length = 0;
    if (fx) {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, fx.width, fx.height);
      fx.style.display = 'none';
      hudHost.style.display = 'none';
    }
  }

  function stopInput() {
    state.down = false;
    state.chargeStart = 0;
    clearInterval(state.autoTimer);
    state.autoTimer = null;
    state.punch = null;
    state.blade.swing = null;
  }

  function setWeapon(w) {
    w = normalize(w);
    if (!w) return;
    state.weapon = w;
    stopInput();
    try { chrome.storage.local.set({ weapon: w }).catch(() => {}); } catch {}
    updateHud();
  }

  function cycle(d) {
    const i = ORDER.indexOf(state.weapon);
    setWeapon(ORDER[(i + d + ORDER.length) % ORDER.length]);
  }

  function reset() {
    for (const d of damaged.values()) {
      d.tiltAnim?.cancel();
      d.fallAnim?.cancel();
    }
    damaged.clear();
    for (const m of marks) m.remove();
    marks.length = 0;
    particles.length = 0;
    zones.length = 0;
    emitters.length = 0;
    bombs.length = 0;
    state.hits = 0;
    updateHud();
  }

  // ---------- Entrada ----------
  function onMove(e) {
    state.x = e.clientX;
    state.y = e.clientY;
    if (state.down && TYPE[state.weapon] === 'blade' && !state.blade.swing) dragCut();
  }

  function onDown(e) {
    if (e.button !== 0) return;
    e.preventDefault();
    try { fx.setPointerCapture(e.pointerId); } catch {}
    state.x = e.clientX;
    state.y = e.clientY;
    state.down = true;
    audio();
    const now = performance.now();
    const w = state.weapon;
    computeAim(now);

    switch (TYPE[w]) {
      case 'whip': startLash(); break;
      case 'throw': throwItem(w); break;
      case 'gun':
        fire(w);
        if (GUNS[w].auto) {
          clearInterval(state.autoTimer);
          state.autoTimer = setInterval(() => { if (state.down) fire(w); }, GUNS[w].auto);
        }
        break;
      case 'bow':
      case 'sling':
        if (ready(w, now)) {
          state.chargeStart = now;
          tone(0.5, 'sawtooth', 70, 110, 0.04);
        }
        break;
      case 'bazooka': fireRocket(); break;
      case 'punch':
        startPunch();
        clearInterval(state.autoTimer);
        state.autoTimer = setInterval(() => { if (state.down) startPunch(); }, 300);
        break;
      case 'blade':
        startSwing(w);
        state.blade.lastX = state.x;
        state.blade.lastY = state.y;
        break;
    }
  }

  function onUp() {
    if (!state.down) return;
    state.down = false;
    clearInterval(state.autoTimer);
    state.autoTimer = null;
    if (state.chargeStart) {
      if (state.weapon === 'arco') fireArrow();
      if (state.weapon === 'estilingue') fireSling();
      state.chargeStart = 0;
    }
  }

  function onKey(e) {
    if (!state.active) return;
    if (e.key === 'Escape') {
      deactivate();
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const t = e.target;
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
    const k = e.key.toLowerCase();
    if (k === 'q' || k === 'e') {
      cycle(k === 'e' ? 1 : -1);
      e.preventDefault();
      e.stopPropagation();
    }
  }

  // ---------- Loop ----------
  function computeAim(now) {
    if (state.weapon === 'sniper') {
      state.aim = {
        x: state.x + Math.sin(now / 650) * 5 + Math.sin(now / 1700) * 3,
        y: state.y + Math.cos(now / 800) * 4
      };
    } else {
      state.aim = { x: state.x, y: state.y };
    }
  }

  function loop(now) {
    if (!state.active) { raf = 0; return; }
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    state.recoil = Math.max(0, state.recoil - dt * 4);
    state.shake = Math.max(0, state.shake - dt * 30);
    computeAim(now);

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, VW, VH);
    if (state.shake > 0) ctx.translate(rand(-state.shake, state.shake), rand(-state.shake, state.shake));

    updateZones(now);
    updateEmitters(now);
    updateBombs(now);
    updateProjectiles(now);
    updateParticles(dt);
    drawWeapon(now);
    if (state.weapon === 'sniper') drawScope(now);
    else if (TYPE[state.weapon] !== 'blade') drawCrosshair(now);

    raf = requestAnimationFrame(loop);
  }

  function drawWeapon(now) {
    switch (TYPE[state.weapon]) {
      case 'whip': drawWhip(now); break;
      case 'throw': drawHandItem(now); break;
      case 'sling': drawSling(now); break;
      case 'bow': drawBow(now); break;
      case 'gun': drawGun(); break;
      case 'bazooka': drawBazooka(now); break;
      case 'blade': drawBlade(now); break;
      case 'punch': drawFist(now); break;
    }
  }

  // ---------- Desenho básico ----------
  const poly = (g, c, ...p) => {
    g.fillStyle = c;
    g.beginPath();
    for (let i = 0; i < p.length; i += 2) i ? g.lineTo(p[i], p[i + 1]) : g.moveTo(p[i], p[i + 1]);
    g.closePath();
    g.fill();
  };
  const rr = (g, c, x, y, w, h, r) => { g.fillStyle = c; g.beginPath(); g.roundRect(x, y, w, h, r); g.fill(); };
  const rc = (g, c, x, y, w, h) => { g.fillStyle = c; g.fillRect(x, y, w, h); };

  const SPR = {};
  function radial(name, stops) {
    if (SPR[name]) return SPR[name];
    const c = document.createElement('canvas');
    c.width = c.height = 128;
    const g = c.getContext('2d');
    const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    for (const [o, col] of stops) grd.addColorStop(o, col);
    g.fillStyle = grd;
    g.fillRect(0, 0, 128, 128);
    return (SPR[name] = c);
  }
  const sprSmoke = () => radial('smoke', [[0, 'rgba(215,215,220,.95)'], [0.45, 'rgba(195,195,202,.6)'], [1, 'rgba(185,185,190,0)']]);
  const sprDark = () => radial('dark', [[0, 'rgba(55,52,50,.9)'], [0.5, 'rgba(45,43,40,.5)'], [1, 'rgba(40,40,40,0)']]);
  const sprFlame = () => radial('flame', [[0, 'rgba(255,250,215,1)'], [0.22, 'rgba(255,205,70,.95)'], [0.55, 'rgba(255,95,15,.6)'], [1, 'rgba(190,30,0,0)']]);

  function blit(img, x, y, r, alpha, add) {
    ctx.globalAlpha = clamp(alpha, 0, 1);
    if (add) ctx.globalCompositeOperation = 'lighter';
    ctx.drawImage(img, x - r, y - r, r * 2, r * 2);
    if (add) ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 1;
  }

  // ---------- Chicote ----------
  function whipAnchor() {
    return { x: VW * 0.66 + (state.x - VW / 2) * 0.15, y: VH - 34 };
  }

  function startLash() {
    if (lash && performance.now() - lash.t0 < LASH_MS * 0.7) return;
    lash = { t0: performance.now(), tx: state.x, ty: state.y, struck: false };
    noise(0.22, 'bandpass', 300, 0.35, 2600, 0.9);
  }

  function ropePoints(A, T, t) {
    const N = 36;
    const dx = T.x - A.x, dy = T.y - A.y;
    const L = Math.hypot(dx, dy) || 1;
    const nx = -dy / L, ny = dx / L;
    let reach, amp;
    if (t < 0.35) {
      const k = t / 0.35;
      reach = 0.55 - 0.15 * k;
      amp = L * 0.25 * k;
    } else if (t < 0.55) {
      const k = (t - 0.35) / 0.2;
      reach = 0.4 + 0.6 * easeOut(k);
      amp = L * 0.25 * (1 - k);
    } else {
      const k = (t - 0.55) / 0.45;
      reach = 1 - 0.45 * k;
      amp = L * 0.06 * Math.sin(k * Math.PI * 3) * (1 - k);
    }
    const pts = [];
    for (let i = 0; i <= N; i++) {
      const s = i / N;
      const off = amp * Math.sin(Math.PI * s) * Math.sin(Math.PI * 2 * (s * 1.2 - t * 2.5));
      pts.push({ x: A.x + dx * reach * s + nx * off, y: A.y + dy * reach * s + ny * off });
    }
    return pts;
  }

  function idleRope(A, now) {
    const E = { x: lerp(A.x, state.x, 0.4), y: lerp(A.y, state.y, 0.4) + 70 };
    const C = { x: (A.x + E.x) / 2 + Math.sin(now / 400) * 10, y: Math.max(A.y, E.y) + 40 };
    const pts = [];
    for (let i = 0; i <= 24; i++) {
      const s = i / 24, u = 1 - s;
      pts.push({ x: u * u * A.x + 2 * u * s * C.x + s * s * E.x, y: u * u * A.y + 2 * u * s * C.y + s * s * E.y });
    }
    return pts;
  }

  function drawWhip(now) {
    const A = whipAnchor();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1e1006';
    ctx.lineWidth = 17;
    ctx.beginPath(); ctx.moveTo(A.x + 26, VH + 40); ctx.lineTo(A.x, A.y); ctx.stroke();
    ctx.strokeStyle = '#6b3d1a';
    ctx.lineWidth = 11;
    ctx.beginPath(); ctx.moveTo(A.x + 26, VH + 40); ctx.lineTo(A.x, A.y); ctx.stroke();

    let pts = null;
    if (lash) {
      const t = (now - lash.t0) / LASH_MS;
      if (t >= 1) {
        lash = null;
      } else {
        pts = ropePoints(A, { x: lash.tx, y: lash.ty }, t);
        if (!lash.struck && t >= 0.55) {
          lash.struck = true;
          impactWhip(lash.tx, lash.ty, A);
        }
      }
    }
    if (!pts) pts = idleRope(A, now);

    for (let i = 0; i < pts.length - 1; i++) {
      const s = i / (pts.length - 1);
      ctx.strokeStyle = s < 0.85 ? '#4a2a10' : '#2b1a0c';
      ctx.lineWidth = lerp(7, 1.6, s);
      ctx.beginPath();
      ctx.moveTo(pts[i].x, pts[i].y);
      ctx.lineTo(pts[i + 1].x, pts[i + 1].y);
      ctx.stroke();
    }
  }

  function impactWhip(x, y, A) {
    const angle = Math.atan2(y - A.y, x - A.x) + Math.PI / 2 + rand(-0.35, 0.35);
    addMark(drawWelt(angle), x, y);
    for (let i = 0; i < 16; i++) {
      const a = rand(0, Math.PI * 2), v = rand(250, 700);
      spawn({ kind: 'spark', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, drag: 4, life: rand(0.15, 0.3), size: rand(1.2, 2.4), color: '#fff3c4' });
    }
    noise(0.06, 'highpass', 2500, 1);
    tone(0.035, 'square', 1800, 500, 0.2);
    noise(0.12, 'bandpass', 900, 0.3, 300, 1, 0.02);
    hitAt(x, y, 1, { x: x - A.x, y: y - A.y });
  }

  // ---------- Soco inglês ----------
  function startPunch() {
    const now = performance.now();
    if (state.punch && now - state.punch.t0 < PUNCH_MS * 0.85) return;
    state.punch = { t0: now, tx: state.x, ty: state.y, hit: false };
    noise(0.12, 'bandpass', 600, 0.25, 2000, 1);
  }

  function drawFist(now) {
    const R = { x: VW * 0.72 + (state.x - VW / 2) * 0.1, y: VH - 70 };
    let F = R, sc = 1.15;
    const p = state.punch;
    if (p) {
      const t = (now - p.t0) / PUNCH_MS;
      if (t >= 1) {
        state.punch = null;
      } else {
        const e = t < 0.4 ? easeOut(t / 0.4) : 1 - easeIn((t - 0.4) / 0.6);
        F = { x: lerp(R.x, p.tx, e), y: lerp(R.y, p.ty, e) };
        sc = lerp(1.15, 0.7, e);
        if (!p.hit && t >= 0.4) {
          p.hit = true;
          impactPunch(p.tx, p.ty, Math.atan2(p.ty - R.y, p.tx - R.x));
        }
      }
    }
    const tgt = state.punch ? { x: state.punch.tx, y: state.punch.ty } : { x: state.x, y: state.y };
    const ang = Math.atan2(tgt.y - R.y, tgt.x - R.x);
    const S = { x: VW * 0.9, y: VH + 260 };
    const back = { x: F.x - Math.cos(ang) * 40 * sc, y: F.y - Math.sin(ang) * 40 * sc };

    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1f2a40';
    ctx.lineWidth = 64 * sc;
    ctx.beginPath(); ctx.moveTo(S.x, S.y); ctx.lineTo(back.x, back.y); ctx.stroke();

    ctx.save();
    ctx.translate(F.x, F.y);
    ctx.rotate(ang);
    ctx.scale(sc, sc);
    ctx.translate(-46, 0);
    ctx.fillStyle = '#e9b48a';
    ctx.strokeStyle = '#a86b45';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.roundRect(-52, -38, 66, 76, 20); ctx.fill(); ctx.stroke();
    for (let i = 0; i < 4; i++) {
      ctx.beginPath(); ctx.roundRect(4, -38 + i * 19, 30, 18, 8); ctx.fill(); ctx.stroke();
    }
    ctx.beginPath(); ctx.roundRect(-24, -46, 38, 16, 8); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = '#d4a62a';
    ctx.lineWidth = 5;
    for (let i = 0; i < 4; i++) {
      ctx.beginPath(); ctx.arc(26, -29 + i * 19, 8, 0, 7); ctx.stroke();
    }
    rr(ctx, '#e6b93a', 34, -42, 12, 84, 5);
    rc(ctx, 'rgba(255,255,255,.35)', 37, -38, 3, 76);
    ctx.restore();
  }

  function impactPunch(x, y, ang) {
    addMark(drawDent(ang), x, y);
    spawn({ kind: 'text', x, y: y - 40, vy: -50, life: 0.7, size: 46, rot: rand(-0.25, 0.25), text: ['POW!', 'PÁ!', 'TUM!', 'SOC!', 'BAM!'][Math.random() * 5 | 0], color: '#ffd60a' });
    for (let i = 0; i < 8; i++) {
      const shade = 100 + Math.random() * 60 | 0;
      spawn({ kind: 'chunk', x, y, vx: rand(-300, 300), vy: rand(-450, -100), g: 1500, life: rand(0.5, 0.9), size: rand(3, 6), vr: rand(-15, 15), color: `rgb(${shade},${shade},${shade})` });
    }
    for (let i = 0; i < 4; i++) {
      spawn({ kind: 'dust', x, y, vx: rand(-50, 50), vy: rand(-50, 0), life: rand(0.4, 0.7), size: rand(10, 18), color: '#9a948a' });
    }
    state.shake = Math.max(state.shake, 5);
    tone(0.16, 'sine', 110, 45, 1);
    noise(0.09, 'lowpass', 1600, 0.8);
    noise(0.03, 'highpass', 2500, 0.3);
    hitAt(x, y, 2.2, dirOf(ang));
  }

  // ---------- Lâminas ----------
  function startSwing(w) {
    const b = state.blade, cfg = BLADES[w], now = performance.now();
    if (b.swing && now - b.swing.t0 < SWING_MS) return;
    const L = cfg.len + cfg.handle;
    b.side = -b.side;
    const ang0 = b.ang;
    const Pv = { x: state.x - Math.cos(ang0) * L, y: state.y - Math.sin(ang0) * L };
    b.swing = { t0: now, ang0, side: b.side, Pv, L, tx: state.x, ty: state.y, done: false };
    spawn({ kind: 'arc', x: Pv.x, y: Pv.y, r: L, a0: ang0 - 1.1, a1: ang0 + 1.1, life: 0.22, size: cfg.width * 0.9 });
    noise(0.16, 'bandpass', 900, 0.35, 4500, 1.2);
  }

  function drawBlade(now) {
    const b = state.blade, cfg = BLADES[state.weapon];
    let tip = { x: state.x, y: state.y }, ang = b.ang;
    const sw = b.swing;
    if (sw) {
      const t = (now - sw.t0) / SWING_MS;
      if (t >= 1) {
        b.swing = null;
      } else {
        ang = sw.ang0 + sw.side * (-1.1 + 2.2 * easeOut(t));
        tip = { x: sw.Pv.x + Math.cos(ang) * sw.L, y: sw.Pv.y + Math.sin(ang) * sw.L };
        if (!sw.done && t >= 0.45) {
          sw.done = true;
          slashImpact(sw, cfg);
        }
      }
    } else if (!state.down) {
      b.ang += angleDiff(-2.3, b.ang) * 0.15;
      ang = b.ang;
    }
    drawBladeSprite(ctx, cfg, tip.x, tip.y, ang);
  }

  function drawBladeSprite(g, cfg, x, y, ang) {
    const L = cfg.len, H = cfg.handle, w = cfg.width;
    g.save();
    g.translate(x, y);
    g.rotate(ang);
    const grd = g.createLinearGradient(0, -w / 2, 0, w / 2);
    grd.addColorStop(0, '#f7f9fb');
    grd.addColorStop(0.5, '#c4cbd2');
    grd.addColorStop(1, '#7e8892');
    g.fillStyle = grd;
    g.beginPath();
    if (cfg.curved) {
      g.moveTo(0, 0);
      g.quadraticCurveTo(-L * 0.3, -w * 0.95, -L, -w * 0.55);
      g.lineTo(-L, w * 0.35);
      g.quadraticCurveTo(-L * 0.4, w * 0.45, 0, 0);
    } else {
      g.moveTo(0, 0);
      g.lineTo(-L * 0.18, -w / 2);
      g.lineTo(-L, -w / 2);
      g.lineTo(-L, w / 2);
      g.lineTo(-L * 0.28, w / 2);
      g.closePath();
    }
    g.fill();
    g.strokeStyle = '#59626c';
    g.lineWidth = 1;
    g.stroke();
    g.strokeStyle = 'rgba(255,255,255,.7)';
    g.beginPath(); g.moveTo(-L * 0.2, -w * 0.15); g.lineTo(-L * 0.92, -w * 0.15); g.stroke();
    if (cfg.guard) {
      rr(g, '#c9a227', -L - 6, -w * 1.9, 9, w * 3.8, 3);
    } else {
      rc(g, '#3a2a1c', -L - 4, -w * 0.65, 6, w * 1.3);
    }
    const hh = Math.max(11, w * 0.85);
    rr(g, cfg.handleColor, -L - 4 - H, -hh / 2, H, hh, 4);
    g.strokeStyle = 'rgba(0,0,0,.35)';
    for (let i = 1; i < 5; i++) {
      const hx = -L - 4 - (H * i) / 5;
      g.beginPath(); g.moveTo(hx, -hh / 2); g.lineTo(hx + 4, hh / 2); g.stroke();
    }
    if (cfg.guard) {
      g.fillStyle = '#c9a227';
      g.beginPath(); g.arc(-L - 8 - H, 0, 6, 0, 7); g.fill();
    }
    g.restore();
  }

  function slashImpact(sw, cfg) {
    const R = sw.L * 0.97;
    const span = cfg.slash / (2 * R);
    const pts = [];
    for (let i = 0; i <= 16; i++) {
      const a = sw.ang0 - span + (2 * span * i) / 16;
      pts.push([sw.Pv.x + Math.cos(a) * R, sw.Pv.y + Math.sin(a) * R]);
    }
    addCutPath(pts, cfg.cut, true);
    if (cfg !== BLADES.faca) {
      for (let i = 0; i < 6; i++) {
        const a = rand(0, Math.PI * 2), v = rand(200, 500);
        spawn({ kind: 'spark', x: sw.tx, y: sw.ty, vx: Math.cos(a) * v, vy: Math.sin(a) * v, drag: 4, life: rand(0.12, 0.25), size: 1.5, color: '#e8f1ff' });
      }
    }
    tone(0.4, 'sine', cfg.ring, cfg.ring * 0.98, 0.05);
    noise(0.08, 'highpass', 3000, 0.3);
    hitAt(sw.tx, sw.ty, cfg.power, { x: -Math.sin(sw.ang0) * sw.side, y: Math.cos(sw.ang0) * sw.side });
  }

  function dragCut() {
    const b = state.blade;
    const dx = state.x - b.lastX, dy = state.y - b.lastY, d = Math.hypot(dx, dy);
    if (d < 14) return;
    const cfg = BLADES[state.weapon];
    addCutPath([[b.lastX, b.lastY], [state.x, state.y]], cfg.cut * 0.8, false);
    b.ang = Math.atan2(dy, dx);
    const now = performance.now();
    if (now - b.lastHit > 140) {
      b.lastHit = now;
      hitAt(state.x, state.y, cfg.power * 0.4, { x: dx, y: dy });
    }
    if (now - b.lastSwish > 130 && d > 28) {
      b.lastSwish = now;
      noise(0.12, 'bandpass', 1200, 0.22, 4000, 1.2);
    }
    b.lastX = state.x;
    b.lastY = state.y;
  }

  // ---------- Arremessos ----------
  function handPos() {
    return { x: VW * 0.5 + (state.x - VW * 0.5) * 0.35, y: VH - 34 };
  }

  function drawHandItem(now) {
    const w = state.weapon;
    if (!ready(w, now)) return;
    const h = handPos();
    drawProjectileSprite(THROWS[w].proj, h.x, h.y, 1.4, w === 'granada' ? -0.3 : 0, now, null);
  }

  function throwItem(w) {
    const now = performance.now();
    if (!ready(w, now)) return;
    const cfg = THROWS[w];
    state.readyAt[w] = now + cfg.cd;
    const s = handPos();
    projectiles.push({
      kind: cfg.proj, sx: s.x, sy: s.y, tx: state.x, ty: state.y, t0: now,
      dur: cfg.dur, h: cfg.h, shape: state.handShape, spin: rand(-12, 12), s0: 1.4, s1: 0.6
    });
    state.handShape = makeStoneShape();
    noise(0.25, 'bandpass', 500, 0.25, 1500, 1);
    if (w === 'granada') {
      tone(0.03, 'square', 2600, 2000, 0.12);
      tone(0.04, 'square', 1700, 1200, 0.1, 0.07);
    }
    if (w === 'molotov') noise(0.4, 'bandpass', 300, 0.2, 900, 0.7);
  }

  function drawProjectileSprite(kind, x, y, s, rot, now, p) {
    const shape = p?.shape || state.handShape;
    switch (kind) {
      case 'stone': drawStone(ctx, x, y, 21 * s, rot, shape); break;
      case 'pebble': drawStone(ctx, x, y, 7 * s, rot, shape); break;
      case 'grenade': drawGrenade(ctx, x, y, 14 * s, rot); break;
      case 'molotov': drawMolotov(ctx, x, y, s, rot, now); break;
      case 'smokecan': drawCanister(ctx, x, y, s, rot); break;
    }
  }

  function impactStone(x, y) {
    addMark(drawGlassCrack(1), x, y);
    for (let i = 0; i < 10; i++) {
      const shade = 90 + Math.random() * 60 | 0;
      spawn({ kind: 'chunk', x, y, vx: rand(-320, 320), vy: rand(-520, -120), g: 1500, life: rand(0.6, 1.1), size: rand(3, 7), vr: rand(-15, 15), color: `rgb(${shade},${shade - 4},${shade - 10})` });
    }
    for (let i = 0; i < 14; i++) {
      spawn({ kind: 'chunk', x, y, vx: rand(-420, 420), vy: rand(-480, -60), g: 1300, life: rand(0.5, 0.9), size: rand(2, 4), vr: rand(-20, 20), color: 'rgba(225,240,255,.9)' });
    }
    for (let i = 0; i < 7; i++) {
      spawn({ kind: 'dust', x: x + rand(-10, 10), y: y + rand(-10, 10), vx: rand(-40, 40), vy: rand(-50, -10), life: rand(0.5, 0.8), size: rand(10, 20), color: '#9a948a' });
    }
    tone(0.18, 'sine', 120, 45, 0.9);
    noise(0.12, 'lowpass', 900, 0.6);
    glassSound(1);
    hitAt(x, y, 2, { x: 0, y: -1 });
  }

  function impactPebble(x, y, power) {
    addMark(drawGlassCrack(0.55), x, y);
    for (let i = 0; i < 8; i++) {
      spawn({ kind: 'chunk', x, y, vx: rand(-300, 300), vy: rand(-400, -80), g: 1300, life: rand(0.4, 0.8), size: rand(1.5, 3.5), vr: rand(-20, 20), color: 'rgba(225,240,255,.9)' });
    }
    tone(0.12, 'sine', 300, 100, 0.5);
    glassSound(0.6);
    hitAt(x, y, 1 + power * 1.5, { x: 0, y: -1 });
  }

  function landGrenade(x, y) {
    bombs.push({ px: x + scrollX, py: y + scrollY, t0: performance.now(), fuse: 1300, rot: rand(-1, 1) });
    tone(0.05, 'triangle', 900, 700, 0.25);
    tone(0.04, 'triangle', 1300, 1000, 0.15, 0.08);
  }

  function updateBombs(now) {
    for (let i = bombs.length - 1; i >= 0; i--) {
      const b = bombs[i];
      const x = b.px - scrollX, y = b.py - scrollY;
      const t = now - b.t0;
      if (t >= b.fuse) {
        bombs.splice(i, 1);
        explode(x, y, 170, 5);
        continue;
      }
      drawGrenade(ctx, x, y, 12, b.rot);
      const fx2 = x + Math.sin(b.rot) * 16, fy2 = y - Math.cos(b.rot) * 16;
      blit(sprFlame(), fx2, fy2, rand(5, 10), 0.9, true);
      if (Math.random() < 0.4) {
        spawn({ kind: 'spark', x: fx2, y: fy2, vx: rand(-120, 120), vy: rand(-200, -40), g: 400, life: rand(0.1, 0.25), size: 1.2, color: '#ffd27a' });
      }
    }
  }

  function impactMolotov(x, y) {
    glassSound(1.2);
    noise(0.7, 'lowpass', 250, 0.9, 1800, 1);
    spawn({ kind: 'flash', x, y, life: 0.2, size: 110 });
    for (let i = 0; i < 16; i++) {
      spawn({ kind: 'chunk', x, y, vx: rand(-380, 380), vy: rand(-450, -60), g: 1300, life: rand(0.5, 0.9), size: rand(2, 4), vr: rand(-20, 20), color: 'rgba(120,170,110,.85)' });
    }
    for (let i = 0; i < 14; i++) {
      spawn({ kind: 'flame', x, y, vx: rand(-260, 260), vy: rand(-260, 40), drag: 3, life: rand(0.4, 0.8), size: rand(20, 36) });
    }
    igniteZone(x, y);
    hitAt(x, y, 1.5, { x: 0, y: -1 });
  }

  function igniteZone(x, y) {
    const now = performance.now();
    zones.push({ px: x + scrollX, py: y + scrollY, r: 80, t0: now, until: now + 4500, nextHit: now + 250, nextCrackle: now });
    addMark(drawScorch(70), x, y);
  }

  function updateZones(now) {
    for (let i = zones.length - 1; i >= 0; i--) {
      const z = zones[i];
      if (now > z.until) { zones.splice(i, 1); continue; }
      const x = z.px - scrollX, y = z.py - scrollY;
      const strength = Math.min(1, ((z.until - now) / (z.until - z.t0)) * 2.5);
      for (let j = 0; j < 3; j++) {
        if (Math.random() > strength) continue;
        const a = rand(0, Math.PI * 2), r = Math.sqrt(Math.random()) * z.r;
        spawn({ kind: 'flame', x: x + Math.cos(a) * r, y: y + Math.sin(a) * r * 0.55, vx: rand(-20, 20), vy: rand(-170, -70), life: rand(0.35, 0.8), size: rand(12, 28) * (0.5 + 0.5 * strength) });
      }
      if (Math.random() < 0.08) {
        spawn({ kind: 'smoke', dark: true, x: x + rand(-z.r, z.r) * 0.5, y: y - 30, vx: rand(-15, 15), vy: rand(-70, -40), life: rand(1.5, 2.5), size: rand(15, 25), grow: 25, alpha: 0.45 });
      }
      if (now > z.nextHit) {
        z.nextHit = now + 420;
        const a = rand(0, Math.PI * 2), r = rand(0, z.r);
        hitAt(x + Math.cos(a) * r, y + Math.sin(a) * r * 0.55, 0.6, { x: 0, y: -1 });
      }
      if (now > z.nextCrackle) {
        z.nextCrackle = now + rand(60, 180);
        noise(0.04, 'bandpass', rand(1500, 4000), 0.12 * strength, 0, 2);
      }
    }
  }

  function landSmoke(x, y) {
    const now = performance.now();
    emitters.push({ px: x + scrollX, py: y + scrollY, until: now + 3600, next: 0, rot: rand(1.2, 1.9) });
    tone(0.08, 'sine', 420, 150, 0.35);
    noise(3.5, 'highpass', 2500, 0.13, 5000, 0.7, 0.05);
  }

  function updateEmitters(now) {
    for (let i = emitters.length - 1; i >= 0; i--) {
      const e = emitters[i];
      if (now > e.until + 2000) { emitters.splice(i, 1); continue; }
      const x = e.px - scrollX, y = e.py - scrollY;
      drawCanister(ctx, x, y, 1, e.rot);
      if (now < e.until && now > e.next) {
        e.next = now + 55;
        spawn({ kind: 'smoke', x: x + rand(-6, 6), y: y - 8, vx: rand(-110, 110), vy: rand(-120, -20), drag: 0.9, life: rand(6, 9), size: rand(22, 40), grow: rand(18, 34), alpha: 0.72 });
      }
    }
  }

  function makeStoneShape() {
    const radii = [];
    for (let i = 0; i < 11; i++) radii.push(0.75 + Math.random() * 0.35);
    return { radii, tone: Math.random() * 30 - 15 };
  }

  function drawStone(g, x, y, r, rot, shape) {
    g.save();
    g.translate(x, y);
    g.rotate(rot);
    g.beginPath();
    shape.radii.forEach((k, i) => {
      const a = (i / shape.radii.length) * Math.PI * 2;
      const px = Math.cos(a) * r * k, py = Math.sin(a) * r * k * 0.85;
      i ? g.lineTo(px, py) : g.moveTo(px, py);
    });
    g.closePath();
    const c = 140 + shape.tone;
    const grd = g.createRadialGradient(-r * 0.35, -r * 0.35, r * 0.1, 0, 0, r * 1.1);
    grd.addColorStop(0, `rgb(${c + 40},${c + 36},${c + 30})`);
    grd.addColorStop(1, `rgb(${c - 70},${c - 72},${c - 76})`);
    g.fillStyle = grd;
    g.fill();
    g.strokeStyle = 'rgba(0,0,0,.55)';
    g.lineWidth = Math.max(1, r * 0.05);
    g.stroke();
    g.restore();
  }

  function drawGrenade(g, x, y, r, rot) {
    g.save();
    g.translate(x, y);
    g.rotate(rot);
    const grd = g.createRadialGradient(-r * 0.35, -r * 0.3, r * 0.1, 0, 0, r * 1.2);
    grd.addColorStop(0, '#7d8f4a');
    grd.addColorStop(1, '#2f3a1a');
    g.fillStyle = grd;
    g.beginPath(); g.ellipse(0, r * 0.1, r * 0.85, r, 0, 0, 7); g.fill();
    g.strokeStyle = 'rgba(0,0,0,.35)';
    g.lineWidth = Math.max(1, r * 0.08);
    for (let i = -1; i <= 1; i++) {
      g.beginPath(); g.moveTo(-r * 0.8, r * 0.1 + i * r * 0.45); g.lineTo(r * 0.8, r * 0.1 + i * r * 0.45); g.stroke();
    }
    g.beginPath(); g.moveTo(0, -r * 0.85); g.lineTo(0, r * 1.05); g.stroke();
    rc(g, '#6b6e72', -r * 0.3, -r * 1.25, r * 0.6, r * 0.4);
    poly(g, '#8a8d91', r * 0.25, -r * 1.2, r * 0.75, -r * 0.95, r * 0.7, -r * 0.2, r * 0.5, -r * 0.25, r * 0.5, -r * 0.9);
    g.strokeStyle = '#b9bcc0';
    g.lineWidth = Math.max(1, r * 0.1);
    g.beginPath(); g.arc(-r * 0.45, -r * 1.15, r * 0.25, 0, 7); g.stroke();
    g.restore();
  }

  function drawMolotov(g, x, y, s, rot, now) {
    g.save();
    g.translate(x, y);
    g.rotate(rot);
    g.scale(s, s);
    g.fillStyle = 'rgba(70,110,60,.92)';
    g.beginPath();
    g.moveTo(-9, 22); g.lineTo(-9, -2); g.quadraticCurveTo(-9, -8, -4, -11); g.lineTo(-4, -20);
    g.lineTo(4, -20); g.lineTo(4, -11); g.quadraticCurveTo(9, -8, 9, -2); g.lineTo(9, 22);
    g.closePath(); g.fill();
    rc(g, 'rgba(214,140,40,.75)', -8, 4, 16, 17);
    rc(g, 'rgba(255,255,255,.35)', -6, -4, 2.5, 24);
    poly(g, '#e8dcc2', -4, -20, -7, -30, 2, -27, 6, -33, 4, -20);
    g.restore();
    const fx2 = x + Math.sin(rot) * 30 * s, fy2 = y - Math.cos(rot) * 30 * s;
    blit(sprFlame(), fx2, fy2 - 4 * s, (11 + Math.sin(now / 50) * 2) * s * 1.2, 0.95, true);
  }

  function drawCanister(g, x, y, s, rot) {
    g.save();
    g.translate(x, y);
    g.rotate(rot);
    g.scale(s, s);
    rr(g, '#4d5560', -9, -18, 18, 36, 4);
    rc(g, '#d9dde2', -9, -4, 18, 8);
    rc(g, '#2c3138', -7, -23, 14, 6);
    rc(g, 'rgba(255,255,255,.25)', -6, -16, 3, 32);
    g.restore();
  }

  // ---------- Estilingue ----------
  function drawSling(now) {
    const P = { x: VW * 0.5 + (state.x - VW * 0.5) * 0.2, y: VH + 10 };
    const a = Math.atan2(state.y - P.y, state.x - P.x);
    const charge = state.chargeStart ? clamp((now - state.chargeStart) / CHARGE_MS, 0, 1) : 0;
    const pouchX = 92 - charge * 60;
    ctx.save();
    ctx.translate(P.x, P.y);
    ctx.rotate(a);
    ctx.lineCap = 'round';
    const wood = (w, c) => {
      ctx.strokeStyle = c;
      ctx.lineWidth = w;
      ctx.beginPath();
      ctx.moveTo(-20, 0); ctx.lineTo(50, 0);
      ctx.moveTo(50, 0); ctx.quadraticCurveTo(62, -30, 100, -34);
      ctx.moveTo(50, 0); ctx.quadraticCurveTo(62, 30, 100, 34);
      ctx.stroke();
    };
    wood(14, '#3b2410');
    wood(9, '#8a5a2b');
    ctx.strokeStyle = '#c2410c';
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(100, -34); ctx.lineTo(pouchX, -7);
    ctx.moveTo(100, 34); ctx.lineTo(pouchX, 7);
    ctx.stroke();
    rr(ctx, '#4a3220', pouchX - 8, -9, 12, 18, 4);
    if (ready('estilingue', now)) drawStone(ctx, pouchX - 1, 0, 7, 0, state.handShape);
    ctx.restore();
    state.slingTip = { x: P.x + Math.cos(a) * 100, y: P.y + Math.sin(a) * 100 };
  }

  function fireSling() {
    const now = performance.now();
    if (!ready('estilingue', now)) return;
    const power = clamp((now - state.chargeStart) / CHARGE_MS, 0.15, 1);
    const s = state.slingTip;
    const dist = Math.hypot(state.x - s.x, state.y - s.y);
    projectiles.push({
      kind: 'pebble', sx: s.x, sy: s.y, tx: state.x, ty: state.y, t0: now,
      dur: clamp((dist / (1000 + power * 1800)) * 1000, 100, 600),
      h: (1 - power) * 100 + 8, power, spin: rand(-20, 20), s0: 1, s1: 0.6, shape: state.handShape
    });
    state.handShape = makeStoneShape();
    state.readyAt.estilingue = now + 300;
    tone(0.15, 'sawtooth', 320, 110, 0.12);
    noise(0.1, 'bandpass', 1500, 0.25);
  }

  // ---------- Arco e flecha ----------
  function drawBow(now) {
    const P = { x: VW * 0.5 + (state.x - VW * 0.5) * 0.2, y: VH - 10 };
    const a = Math.atan2(state.y - P.y, state.x - P.x);
    const charge = state.chargeStart ? clamp((now - state.chargeStart) / CHARGE_MS, 0, 1) : 0;
    const pull = charge * 48;
    const nockX = 30 - pull;
    const shake = charge >= 1 ? rand(-0.6, 0.6) : 0;

    ctx.save();
    ctx.translate(P.x + shake, P.y + shake);
    ctx.rotate(a);
    ctx.lineCap = 'round';
    for (const [w, c] of [[9, '#3b2410'], [5, '#8a5a2b']]) {
      ctx.strokeStyle = c;
      ctx.lineWidth = w;
      ctx.beginPath(); ctx.moveTo(30, -95); ctx.quadraticCurveTo(110 - pull * 0.3, 0, 30, 95); ctx.stroke();
    }
    ctx.strokeStyle = '#1d140c';
    ctx.lineWidth = 11;
    ctx.beginPath(); ctx.moveTo(68 - pull * 0.15, -14); ctx.lineTo(68 - pull * 0.15, 14); ctx.stroke();
    ctx.strokeStyle = 'rgba(240,240,230,.9)';
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(30, -95); ctx.lineTo(nockX, 0); ctx.lineTo(30, 95); ctx.stroke();
    if (ready('arco', now)) {
      ctx.save();
      ctx.translate(nockX, 0);
      drawArrowLocal(ctx, 125);
      ctx.restore();
    }
    ctx.restore();

    const tipX = nockX + 125;
    state.bowTip = { x: P.x + Math.cos(a) * tipX, y: P.y + Math.sin(a) * tipX };
  }

  function drawArrowLocal(g, len) {
    g.lineCap = 'round';
    for (const [w, c] of [[4.5, '#3d2410'], [2.4, '#b07f4c']]) {
      g.strokeStyle = c;
      g.lineWidth = w;
      g.beginPath(); g.moveTo(6, 0); g.lineTo(len - 14, 0); g.stroke();
    }
    g.fillStyle = '#9aa3ad';
    g.strokeStyle = '#4b5560';
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(len, 0); g.lineTo(len - 18, -6); g.lineTo(len - 14, 0); g.lineTo(len - 18, 6);
    g.closePath(); g.fill(); g.stroke();
    for (const s of [-1, 1]) poly(g, '#d8392b', 32, 0, 12, 9 * s, -1, 9 * s, 7, 0);
    rc(g, '#222', 0, -2, 5, 4);
  }

  function fireArrow() {
    const now = performance.now();
    if (!ready('arco', now)) return;
    const power = clamp((now - state.chargeStart) / CHARGE_MS, 0.15, 1);
    const s = state.bowTip;
    const dist = Math.hypot(state.x - s.x, state.y - s.y);
    projectiles.push({
      kind: 'arrow', sx: s.x, sy: s.y, tx: state.x, ty: state.y, t0: now,
      dur: clamp((dist / (900 + power * 1600)) * 1000, 120, 700),
      h: (1 - power) * 120 + 10, power, ang: 0
    });
    state.readyAt.arco = now + 350;
    tone(0.28, 'triangle', 180 + power * 40, 160, 0.35);
    noise(0.14, 'bandpass', 700, 0.2, 3000, 1);
  }

  function impactArrow(x, y, ang, power) {
    const mark = drawArrowStuck(ang, power);
    addMark(mark, x, y);
    mark.animate(
      [{ transform: 'rotate(0deg)' }, { transform: 'rotate(5deg)' }, { transform: 'rotate(-4deg)' }, { transform: 'rotate(2.5deg)' }, { transform: 'rotate(-1deg)' }, { transform: 'rotate(0deg)' }],
      { duration: 650, easing: 'ease-out' }
    );
    for (let i = 0; i < 7; i++) {
      spawn({ kind: 'chunk', x, y, vx: rand(-260, 260), vy: rand(-420, -80), g: 1400, life: rand(0.5, 0.9), size: rand(2, 4), vr: rand(-20, 20), color: '#a0784a' });
    }
    tone(0.12, 'sine', 240, 70, 0.7);
    noise(0.06, 'bandpass', 1500, 0.6);
    hitAt(x, y, 1 + power * 2, dirOf(ang));
  }

  // ---------- Armas de fogo ----------
  const GUN_SHAPES = {
    pistola(g) {
      poly(g, '#18191c', 70, 6, 112, 6, 92, 80, 54, 74);
      rr(g, '#2c2f35', 50, -20, 190, 30, 6);
      rr(g, '#4a4f57', 50, -20, 190, 9, [6, 6, 0, 0]);
      g.strokeStyle = 'rgba(0,0,0,.45)';
      g.lineWidth = 2;
      for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(62 + i * 7, -18); g.lineTo(62 + i * 7, 6); g.stroke(); }
      rc(g, '#0d0e10', 236, -14, 10, 18);
      rc(g, '#e8433a', 228, -25, 6, 6);
    },
    mp5(g) {
      rc(g, '#1b1c1f', -20, -14, 85, 6);
      rc(g, '#1b1c1f', -20, -14, 7, 30);
      poly(g, '#17181a', 90, 8, 116, 8, 106, 66, 80, 62);
      g.fillStyle = '#17181a';
      g.beginPath(); g.moveTo(132, 8); g.quadraticCurveTo(140, 40, 156, 68); g.lineTo(172, 62); g.quadraticCurveTo(156, 36, 152, 8); g.closePath(); g.fill();
      rr(g, '#26282c', 55, -22, 180, 30, 5);
      rr(g, '#3d4046', 55, -22, 180, 8, [5, 5, 0, 0]);
      rr(g, '#1e1f22', 175, -17, 70, 24, 7);
      rc(g, '#111', 245, -12, 24, 10);
      rc(g, '#111', 70, -31, 12, 9);
      rc(g, '#111', 222, -31, 6, 9);
    },
    m4(g) {
      poly(g, '#23262b', -50, -16, 55, -20, 55, 8, -38, 24, -50, 24);
      poly(g, '#1c1e21', 98, 8, 124, 8, 116, 64, 90, 60);
      poly(g, '#3a3f45', 142, 8, 172, 8, 180, 66, 150, 68);
      rr(g, '#2f3338', 50, -24, 155, 32, 4);
      rr(g, '#26292d', 205, -20, 120, 26, 4);
      for (let x = 210; x < 320; x += 9) rc(g, '#1a1c1f', x, -25, 5, 5);
      rc(g, '#1f2226', 85, -36, 46, 12);
      rc(g, '#1f2226', 306, -38, 6, 18);
      rc(g, '#141518', 325, -11, 44, 8);
      rc(g, '#0e0f10', 365, -13, 12, 12);
    },
    ak47(g) {
      poly(g, '#8b5a2b', -50, -8, 60, -18, 60, 8, -46, 28);
      poly(g, '#7a4c22', 96, 6, 120, 6, 112, 60, 88, 56);
      g.fillStyle = '#26272a';
      g.beginPath(); g.moveTo(142, 6); g.quadraticCurveTo(150, 40, 174, 68); g.lineTo(196, 58); g.quadraticCurveTo(174, 36, 170, 6); g.closePath(); g.fill();
      rr(g, '#2a2b2e', 55, -22, 145, 28, 4);
      rc(g, '#3a3c40', 60, -25, 135, 6);
      rc(g, '#2b2c2f', 200, -24, 100, 7);
      rr(g, '#8b5a2b', 198, -17, 92, 22, 7);
      rc(g, '#18191b', 290, -10, 66, 7);
      rc(g, '#18191b', 340, -22, 6, 13);
      rc(g, '#0f1011', 352, -12, 8, 11);
    },
    sniper(g) {
      poly(g, '#4a4a35', -70, -12, 75, -16, 75, 10, 25, 12, -10, 32, -70, 32);
      poly(g, '#3f3f2e', 104, 6, 128, 6, 120, 56, 98, 52);
      rr(g, '#2b2c2e', 72, -20, 125, 26, 5);
      g.strokeStyle = '#1a1a1a';
      g.lineWidth = 4;
      g.beginPath(); g.moveTo(155, -6); g.lineTo(166, 14); g.stroke();
      g.fillStyle = '#1a1a1a';
      g.beginPath(); g.arc(167, 16, 5, 0, 7); g.fill();
      rc(g, '#1d1e20', 195, -12, 240, 8);
      rc(g, '#151617', 412, -14, 26, 12);
      rc(g, '#202122', 122, -30, 8, 12);
      rc(g, '#202122', 182, -30, 8, 12);
      rr(g, '#151617', 100, -46, 110, 18, 8);
      rr(g, '#101112', 92, -49, 16, 24, 4);
      rr(g, '#101112', 202, -52, 20, 30, 5);
      rc(g, 'rgba(120,180,255,.35)', 218, -48, 3, 22);
    }
  };

  function drawGun() {
    const w = state.weapon, cfg = GUNS[w];
    const P = { x: VW * cfg.px + (state.x - VW / 2) * 0.08, y: VH + cfg.py };
    const a = Math.atan2(state.aim.y - P.y, state.aim.x - P.x);
    const back = state.recoil * cfg.back;
    ctx.save();
    ctx.translate(P.x, P.y);
    ctx.rotate(a);
    ctx.translate(-back, 0);
    GUN_SHAPES[w](ctx);
    ctx.restore();
    const rot = (lx, ly) => ({ x: P.x + Math.cos(a) * lx - Math.sin(a) * ly, y: P.y + Math.sin(a) * lx + Math.cos(a) * ly });
    state.muzzle = rot(cfg.tip - back, cfg.my);
    state.eject = rot(cfg.ej - back, -20);
  }

  function fire(w) {
    const cfg = GUNS[w], now = performance.now();
    if (!ready(w, now)) return;
    state.readyAt[w] = now + (cfg.cd || 0);
    const sp = cfg.spread * (0.3 + state.recoil);
    const tx = state.aim.x + rand(-sp, sp), ty = state.aim.y + rand(-sp, sp);
    state.recoil = Math.min(1, state.recoil + cfg.kick);
    const m = state.muzzle;
    const big = w === 'sniper';
    if (big) state.shake = Math.max(state.shake, 7);

    spawn({ kind: 'flash', x: m.x, y: m.y, life: 0.06, size: big ? 70 : 48 });
    spawn({ kind: 'tracer', x: m.x, y: m.y, x2: tx, y2: ty, life: big ? 0.09 : 0.05 });
    spawn({ kind: 'shell', x: state.eject.x, y: state.eject.y, vx: rand(120, 300), vy: rand(-520, -380), g: 1600, life: 1.2, vr: rand(-20, 20), size: big ? 1.6 : 1 });
    spawn({ kind: 'flash', x: tx, y: ty, life: 0.05, size: big ? 40 : 22 });
    for (let i = 0; i < (big ? 18 : 9); i++) {
      const a = rand(0, Math.PI * 2), v = rand(200, big ? 900 : 600);
      spawn({ kind: 'spark', x: tx, y: ty, vx: Math.cos(a) * v, vy: Math.sin(a) * v, drag: 5, g: 600, life: rand(0.12, 0.3), size: rand(1.2, 2.2), color: '#ffcf5a' });
    }
    for (let i = 0; i < (big ? 8 : 3); i++) {
      spawn({ kind: 'dust', x: tx, y: ty, vx: rand(-40, 40), vy: rand(-50, 0), life: rand(0.4, 0.8), size: rand(6, big ? 22 : 12), color: '#8f8a82' });
    }
    if (big) addMark(drawGlassCrack(0.8), tx, ty);
    addMark(drawBulletHole(cfg.hole), tx, ty);
    gunSound(w);
    hitAt(tx, ty, cfg.dmg, { x: tx - m.x, y: ty - m.y });
  }

  function drawScope(now) {
    const { x, y } = state.aim;
    const R = Math.min(170, Math.min(VW, VH) * 0.3);
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,.82)';
    ctx.beginPath();
    ctx.rect(-60, -60, VW + 120, VH + 120);
    ctx.arc(x, y, R, 0, Math.PI * 2);
    ctx.fill('evenodd');
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 8;
    ctx.beginPath(); ctx.arc(x, y, R, 0, 7); ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,.85)';
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(x - R, y); ctx.lineTo(x + R, y); ctx.moveTo(x, y - R); ctx.lineTo(x, y + R); ctx.stroke();
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(x - R, y); ctx.lineTo(x - R * 0.35, y);
    ctx.moveTo(x + R * 0.35, y); ctx.lineTo(x + R, y);
    ctx.moveTo(x, y + R * 0.35); ctx.lineTo(x, y + R);
    ctx.stroke();
    ctx.fillStyle = '#000';
    for (let i = -4; i <= 4; i++) {
      if (!i) continue;
      ctx.beginPath(); ctx.arc(x + i * R * 0.08, y, 2, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(x, y + i * R * 0.08, 2, 0, 7); ctx.fill();
    }
    ctx.fillStyle = '#ff2d2d';
    ctx.beginPath(); ctx.arc(x, y, 2.2, 0, 7); ctx.fill();
    if (!ready('sniper', now)) {
      const p = 1 - (state.readyAt.sniper - now) / GUNS.sniper.cd;
      ctx.strokeStyle = 'rgba(255,255,255,.6)';
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(x, y, R + 10, -Math.PI / 2, -Math.PI / 2 + p * Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
  }

  // ---------- Bazuca ----------
  function drawBazooka(now) {
    const P = { x: VW * 0.8 + (state.x - VW / 2) * 0.08, y: VH + 60 };
    const a = Math.atan2(state.y - P.y, state.x - P.x);
    const back = state.recoil * 30;
    ctx.save();
    ctx.translate(P.x, P.y);
    ctx.rotate(a);
    ctx.translate(-back, 0);
    poly(ctx, '#1d1f1a', 110, 12, 130, 12, 124, 58, 104, 56);
    poly(ctx, '#1d1f1a', 160, 12, 176, 12, 172, 46, 156, 44);
    const grd = ctx.createLinearGradient(0, -18, 0, 18);
    grd.addColorStop(0, '#6d7a45');
    grd.addColorStop(0.5, '#55613a');
    grd.addColorStop(1, '#3a4227');
    rr(ctx, grd, -60, -18, 330, 36, 6);
    rc(ctx, '#2a2f1d', -60, -20, 18, 40);
    rc(ctx, '#2a2f1d', 252, -20, 18, 40);
    rc(ctx, '#2a2f1d', 90, -19, 8, 38);
    rc(ctx, '#222', 140, -34, 26, 14);
    if (ready('bazuca', now)) poly(ctx, '#7b2d1e', 270, -11, 300, 0, 270, 11);
    ctx.restore();
    const rot = (lx, ly) => ({ x: P.x + Math.cos(a) * lx - Math.sin(a) * ly, y: P.y + Math.sin(a) * lx + Math.cos(a) * ly });
    state.muzzle = rot(272 - back, 0);
    state.rear = rot(-62 - back, 0);
  }

  function fireRocket() {
    const now = performance.now();
    if (!ready('bazuca', now)) return;
    state.readyAt.bazuca = now + 1100;
    const m = state.muzzle, r = state.rear;
    const dist = Math.hypot(state.x - m.x, state.y - m.y);
    projectiles.push({ kind: 'rocket', sx: m.x, sy: m.y, tx: state.x, ty: state.y, t0: now, dur: clamp(dist / 1.1, 200, 900) });
    state.recoil = 1;
    state.shake = Math.max(state.shake, 5);
    spawn({ kind: 'flash', x: m.x, y: m.y, life: 0.1, size: 70 });
    const bx = r.x - m.x, by = r.y - m.y, bl = Math.hypot(bx, by) || 1;
    for (let i = 0; i < 12; i++) {
      const v = rand(100, 300);
      spawn({ kind: 'smoke', dark: i % 2 === 0, x: r.x, y: r.y, vx: (bx / bl) * v + rand(-60, 60), vy: (by / bl) * v + rand(-60, 60), drag: 2, life: rand(1, 2), size: rand(15, 30), grow: 40, alpha: 0.6 });
    }
    noise(0.7, 'bandpass', 500, 0.8, 2200, 0.8);
    tone(0.35, 'sawtooth', 70, 220, 0.18);
    noise(0.15, 'lowpass', 2000, 0.6);
  }

  function drawRocket(g, x, y, ang) {
    g.save();
    g.translate(x, y);
    g.rotate(ang);
    g.translate(-14, 0);
    poly(g, '#3c4528', -46, -6, -58, -15, -40, -6);
    poly(g, '#3c4528', -46, 6, -58, 15, -40, 6);
    rr(g, '#5c6b3c', -48, -6, 44, 12, 3);
    poly(g, '#7b2d1e', -6, -6, 14, 0, -6, 6);
    g.restore();
  }

  // ---------- Explosões ----------
  function explode(x, y, R, power) {
    addMark(drawScorch(R), x, y);
    spawn({ kind: 'flash', x, y, life: 0.18, size: R * 1.4 });
    spawn({ kind: 'ring', x, y, life: 0.35, size: 10, grow: R * 4 });
    for (let i = 0; i < 16; i++) {
      spawn({ kind: 'flame', x: x + rand(-R, R) * 0.2, y: y + rand(-R, R) * 0.2, vx: rand(-R, R) * 1.3, vy: rand(-R, R) * 1.3 - 40, drag: 3, life: rand(0.35, 0.75), size: rand(R * 0.3, R * 0.55) });
    }
    for (let i = 0; i < 22; i++) {
      const shade = 40 + Math.random() * 60 | 0;
      spawn({ kind: 'chunk', x, y, vx: rand(-R * 4, R * 4), vy: rand(-R * 5, -R), g: 1600, life: rand(0.7, 1.3), size: rand(3, 8), vr: rand(-20, 20), color: `rgb(${shade},${shade - 5},${shade - 10})` });
    }
    for (let i = 0; i < 20; i++) {
      const a = rand(0, Math.PI * 2), v = rand(300, 900);
      spawn({ kind: 'spark', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, drag: 3, g: 500, life: rand(0.2, 0.5), size: rand(1.5, 3), color: '#ffcf5a' });
    }
    for (let i = 0; i < 10; i++) {
      spawn({ kind: 'smoke', dark: true, x: x + rand(-R, R) * 0.4, y: y + rand(-R, R) * 0.4, vx: rand(-60, 60), vy: rand(-80, -20), drag: 1, life: rand(2, 3.5), size: rand(R * 0.2, R * 0.35), grow: 35, alpha: 0.6 });
    }
    spawn({ kind: 'text', x, y: y - R * 0.35, vy: -40, life: 0.9, size: Math.round(R * 0.38), rot: rand(-0.2, 0.2), text: 'BUUM!', color: '#ffb020' });
    state.shake = Math.max(state.shake, R / 14);
    noise(1.5, 'lowpass', 1400, 1.2, 50);
    tone(1, 'sine', 70, 22, 1.2);
    noise(0.35, 'highpass', 1800, 0.35, 500);
    noise(1.2, 'bandpass', 260, 0.5, 70, 0.8, 0.12);

    state.hits++;
    updateHud();
    const seen = new Set();
    for (const f of [0, 0.35, 0.7, 1]) {
      const n = f ? 10 : 1;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        const px = x + Math.cos(a) * R * f, py = y + Math.sin(a) * R * f;
        if (px < 0 || py < 0 || px > VW || py > VH) continue;
        const el = targetAt(px, py);
        if (!el || seen.has(el)) continue;
        seen.add(el);
        hitEl(el, power * (1 - f * 0.6), f ? dirOf(a) : { x: 0, y: -1 });
      }
    }
  }

  // ---------- Projéteis ----------
  function updateProjectiles(now) {
    for (let i = projectiles.length - 1; i >= 0; i--) {
      const p = projectiles[i];
      const t = Math.min(1, (now - p.t0) / p.dur);
      if (p.kind === 'rocket') {
        const e = 0.35 * t + 0.65 * t * t;
        const x = lerp(p.sx, p.tx, e), y = lerp(p.sy, p.ty, e);
        const ang = Math.atan2(p.ty - p.sy, p.tx - p.sx);
        const bk = dirOf(ang + Math.PI);
        spawn({ kind: 'smoke', x: x + bk.x * 44, y: y + bk.y * 44, vx: rand(-15, 15), vy: rand(-25, 5), life: rand(1, 1.6), size: rand(8, 14), grow: 30, alpha: 0.5 });
        spawn({ kind: 'flame', x: x + bk.x * 48, y: y + bk.y * 48, vx: bk.x * 120, vy: bk.y * 120, life: 0.12, size: rand(10, 16) });
        drawRocket(ctx, x, y, ang);
      } else {
        const x = lerp(p.sx, p.tx, t);
        const y = lerp(p.sy, p.ty, t) - p.h * 4 * t * (1 - t);
        if (p.kind === 'arrow') {
          p.ang = Math.atan2((p.ty - p.sy) - p.h * 4 * (1 - 2 * t), p.tx - p.sx);
          ctx.save();
          ctx.translate(x, y);
          ctx.rotate(p.ang);
          const sc = lerp(1, 0.8, t);
          ctx.scale(sc, sc);
          ctx.translate(-125, 0);
          drawArrowLocal(ctx, 125);
          ctx.restore();
        } else {
          const rot = p.spin * t, s = lerp(p.s0, p.s1, t);
          drawProjectileSprite(p.kind, x, y, s, rot, now, p);
          if (p.kind === 'molotov') {
            spawn({ kind: 'flame', x: x + Math.sin(rot) * 30 * s, y: y - Math.cos(rot) * 30 * s, vx: rand(-20, 20), vy: rand(-60, -20), life: 0.25, size: rand(6, 12) });
          }
        }
      }
      if (t >= 1) {
        projectiles.splice(i, 1);
        impact(p);
      }
    }
  }

  function impact(p) {
    switch (p.kind) {
      case 'stone': impactStone(p.tx, p.ty); break;
      case 'pebble': impactPebble(p.tx, p.ty, p.power); break;
      case 'arrow': impactArrow(p.tx, p.ty, p.ang, p.power); break;
      case 'grenade': landGrenade(p.tx, p.ty); break;
      case 'molotov': impactMolotov(p.tx, p.ty); break;
      case 'smokecan': landSmoke(p.tx, p.ty); break;
      case 'rocket': explode(p.tx, p.ty, 230, 9); break;
    }
  }

  // ---------- Partículas ----------
  function spawn(p) {
    if (particles.length >= MAX_PARTICLES) particles.shift();
    const q = Object.assign({ vx: 0, vy: 0, g: 0, drag: 0, rot: rand(0, 6), vr: 0, size: 3, grow: 0, color: '#fff' }, p);
    q.max = q.life;
    particles.push(q);
  }

  function updateParticles(dt) {
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.life -= dt;
      if (p.life <= 0) { particles.splice(i, 1); continue; }
      const damp = 1 - Math.min(1, p.drag * dt);
      p.vx *= damp;
      p.vy *= damp;
      p.vy += p.g * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
      p.size += p.grow * dt;
      const k = p.life / p.max;
      const age = p.max - p.life;
      ctx.globalAlpha = k;

      switch (p.kind) {
        case 'spark':
          ctx.strokeStyle = p.color;
          ctx.lineWidth = p.size;
          ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * 0.03, p.y - p.vy * 0.03); ctx.stroke();
          break;
        case 'chunk':
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          ctx.fillStyle = p.color; ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.7);
          ctx.restore();
          break;
        case 'dust':
          ctx.globalAlpha = k * 0.35;
          ctx.fillStyle = p.color;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1 + (1 - k) * 2), 0, 7); ctx.fill();
          break;
        case 'flash':
          blit(sprFlame(), p.x, p.y, p.size * (0.6 + 0.4 * k), 1, true);
          break;
        case 'flame':
          blit(sprFlame(), p.x, p.y, p.size * (0.35 + 0.65 * k), k, true);
          break;
        case 'smoke': {
          const a = Math.min(1, (age / p.max) * 5) * Math.min(1, k * 2) * (p.alpha ?? 0.6);
          blit(p.dark ? sprDark() : sprSmoke(), p.x, p.y, p.size, a, false);
          break;
        }
        case 'ring':
          ctx.strokeStyle = `rgba(255,240,210,${k * 0.7})`;
          ctx.lineWidth = 2 + 6 * k;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, 7); ctx.stroke();
          break;
        case 'arc':
          ctx.strokeStyle = `rgba(255,255,255,${k * 0.6})`;
          ctx.lineWidth = p.size * k + 1;
          ctx.lineCap = 'round';
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, p.a0, p.a1); ctx.stroke();
          break;
        case 'tracer':
          ctx.strokeStyle = 'rgba(255,230,150,.9)';
          ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x2, p.y2); ctx.stroke();
          break;
        case 'shell':
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.scale(p.size, p.size);
          ctx.fillStyle = '#d4a63a'; ctx.fillRect(-5, -2.2, 10, 4.4);
          ctx.fillStyle = '#8a6a1e'; ctx.fillRect(3, -2.2, 2, 4.4);
          ctx.restore();
          break;
        case 'text': {
          const s = age < 0.12 ? lerp(0.3, 1.25, age / 0.12) : lerp(1.25, 1, Math.min(1, (age - 0.12) / 0.15));
          ctx.globalAlpha = Math.min(1, k * 2);
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.scale(s, s);
          ctx.font = `900 ${p.size}px Impact, "Arial Black", sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.lineJoin = 'round';
          ctx.lineWidth = p.size * 0.16;
          ctx.strokeStyle = '#111';
          ctx.strokeText(p.text, 0, 0);
          ctx.fillStyle = p.color;
          ctx.fillText(p.text, 0, 0);
          ctx.restore();
          break;
        }
      }
    }
    ctx.globalAlpha = 1;
  }

  // ---------- Mira ----------
  function drawCrosshair(now) {
    const t = TYPE[state.weapon];
    const col = t === 'gun' || t === 'bazooka' ? '#ff3b30' : t === 'bow' || t === 'sling' ? '#ffd60a' : '#ffffff';
    const gap = t === 'gun' ? 6 + state.recoil * 16 : 7;
    const len = 9;
    ctx.save();
    ctx.translate(state.x, state.y);
    ctx.lineCap = 'round';
    const both = (fn) => {
      ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 4; fn();
      ctx.strokeStyle = col; ctx.lineWidth = 2; fn();
    };
    both(() => {
      ctx.beginPath();
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        ctx.moveTo(dx * gap, dy * gap);
        ctx.lineTo(dx * (gap + len), dy * (gap + len));
      }
      ctx.stroke();
    });
    if ((t === 'bow' || t === 'sling') && state.chargeStart) {
      const c = clamp((now - state.chargeStart) / CHARGE_MS, 0, 1);
      both(() => { ctx.beginPath(); ctx.arc(0, 0, 24, -Math.PI / 2, -Math.PI / 2 + c * Math.PI * 2); ctx.stroke(); });
    }
    ctx.fillStyle = col;
    ctx.beginPath(); ctx.arc(0, 0, 1.8, 0, 7); ctx.fill();
    ctx.restore();
  }

  // ---------- Marcas na página ----------
  function makeCanvas(w, h = w) {
    w = Math.max(2, Math.ceil(w));
    h = Math.max(2, Math.ceil(h));
    const c = document.createElement('canvas');
    c.width = Math.round(w * dpr);
    c.height = Math.round(h * dpr);
    c._w = w;
    c._h = h;
    const g = c.getContext('2d');
    g.scale(dpr, dpr);
    return [c, g];
  }

  function placeMark(c, left, top) {
    c._px = left + scrollX + c._w / 2;
    c._py = top + scrollY + c._h / 2;
    c.style.cssText = `all:initial;position:absolute;left:${left + scrollX}px;top:${top + scrollY}px;width:${c._w}px;height:${c._h}px;pointer-events:none;`;
    marksLayer.appendChild(c);
    marks.push(c);
    if (marks.length > MAX_MARKS) marks.shift().remove();
  }

  function addMark(c, x, y) {
    placeMark(c, x - c._w / 2, y - c._h / 2);
  }

  function crackPath(x, y, a, L, steps) {
    const pts = [[x, y]];
    let cx = x, cy = y;
    for (let i = 1; i <= steps; i++) {
      const aa = a + (Math.random() - 0.5) * 0.7;
      cx += Math.cos(aa) * (L / steps);
      cy += Math.sin(aa) * (L / steps);
      pts.push([cx, cy]);
    }
    return pts;
  }

  function strokePts(g, pts, w, color) {
    g.strokeStyle = color;
    g.lineWidth = w;
    g.beginPath();
    g.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]);
    g.stroke();
  }

  function strokeTapered(g, pts, w, color) {
    g.strokeStyle = color;
    const n = pts.length - 1;
    for (let i = 0; i < n; i++) {
      g.lineWidth = Math.max(0.6, w * Math.sin(Math.PI * (i + 0.5) / n));
      g.beginPath();
      g.moveTo(pts[i][0], pts[i][1]);
      g.lineTo(pts[i + 1][0], pts[i + 1][1]);
      g.stroke();
    }
  }

  function strokeCrack(g, pts, w) {
    strokePts(g, pts, w + 1.4, 'rgba(0,0,0,.45)');
    strokePts(g, pts, w, 'rgba(255,255,255,.85)');
  }

  function offsetPts(pts, d) {
    return pts.map((p, i) => {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)];
      const dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1;
      return [p[0] - (dy / l) * d, p[1] + (dx / l) * d];
    });
  }

  function addCutPath(pts, w, tapered) {
    const pad = w + 6;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const [x, y] of pts) {
      minX = Math.min(minX, x); minY = Math.min(minY, y);
      maxX = Math.max(maxX, x); maxY = Math.max(maxY, y);
    }
    const [c, g] = makeCanvas(maxX - minX + pad * 2, maxY - minY + pad * 2);
    const local = pts.map(([x, y]) => [x - minX + pad, y - minY + pad]);
    g.lineCap = 'round';
    g.lineJoin = 'round';
    const draw = tapered ? strokeTapered : strokePts;
    draw(g, local, w + 4, 'rgba(0,0,0,.18)');
    draw(g, local, w, 'rgba(14,8,8,.92)');
    draw(g, offsetPts(local, w * 0.5 + 0.8), 1, 'rgba(255,255,255,.6)');
    placeMark(c, minX - pad, minY - pad);
  }

  function drawBulletHole(scale) {
    const S = 70 * scale, [c, g] = makeCanvas(S), m = c._w / 2;
    g.lineCap = 'round';
    g.lineJoin = 'round';
    const n = 6 + (Math.random() * 4 | 0);
    for (let i = 0; i < n; i++) {
      strokeCrack(g, crackPath(m, m, rand(0, Math.PI * 2), rand(12, 30) * scale, 4), 0.8);
    }
    const r = 13 * scale;
    const grd = g.createRadialGradient(m, m, 2, m, m, r);
    grd.addColorStop(0, 'rgba(0,0,0,.95)');
    grd.addColorStop(0.45, 'rgba(40,40,40,.8)');
    grd.addColorStop(0.7, 'rgba(170,170,170,.45)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.beginPath(); g.arc(m, m, r, 0, 7); g.fill();
    g.fillStyle = '#050505';
    g.beginPath(); g.arc(m, m, 4.2 * scale, 0, 7); g.fill();
    return c;
  }

  function drawGlassCrack(scale) {
    const S = 300 * scale, [c, g] = makeCanvas(S), m = c._w / 2;
    g.lineCap = 'round';
    g.lineJoin = 'round';
    const n = 9 + (Math.random() * 6 | 0);
    const rays = [];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + rand(-0.25, 0.25);
      rays.push(crackPath(m, m, a, rand(60 * scale, m - 8), 7));
    }
    for (const r of rays) strokeCrack(g, r, 1.1);
    for (const k of [2, 4, 6]) {
      for (let i = 0; i < n; i++) {
        if (Math.random() < 0.35) continue;
        const p1 = rays[i][k], p2 = rays[(i + 1) % n][k];
        const mid = [(p1[0] + p2[0]) / 2 + rand(-6, 6), (p1[1] + p2[1]) / 2 + rand(-6, 6)];
        strokeCrack(g, [p1, mid, p2], 0.8);
      }
    }
    const grd = g.createRadialGradient(m, m, 0, m, m, 18 * scale);
    grd.addColorStop(0, 'rgba(255,255,255,.9)');
    grd.addColorStop(0.5, 'rgba(200,215,230,.5)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.beginPath(); g.arc(m, m, 18 * scale, 0, 7); g.fill();
    return c;
  }

  function drawWelt(angle) {
    const [c, g] = makeCanvas(240), m = 120;
    const len = rand(75, 105), bend = rand(-18, -8);
    g.translate(m, m);
    g.rotate(angle);
    g.lineCap = 'round';
    g.shadowColor = 'rgba(170,0,0,.6)';
    g.shadowBlur = 9;
    g.strokeStyle = 'rgba(140,10,10,.75)';
    g.lineWidth = 8;
    g.beginPath(); g.moveTo(-len, 5); g.quadraticCurveTo(0, bend, len, 3); g.stroke();
    g.shadowBlur = 0;
    g.strokeStyle = 'rgba(255,95,95,.85)';
    g.lineWidth = 2.5;
    g.beginPath(); g.moveTo(-len * 0.9, 3); g.quadraticCurveTo(0, bend - 2, len * 0.9, 1); g.stroke();
    g.fillStyle = 'rgba(110,0,0,.7)';
    for (let i = 0; i < 10; i++) {
      const s = rand(-1, 1);
      g.beginPath(); g.arc(s * len, bend * (1 - s * s) + rand(-6, 6), rand(0.8, 2), 0, 7); g.fill();
    }
    return c;
  }

  function drawDent(ang) {
    const [c, g] = makeCanvas(170), m = 85;
    const grd = g.createRadialGradient(m, m, 4, m, m, 55);
    grd.addColorStop(0, 'rgba(0,0,0,.38)');
    grd.addColorStop(0.55, 'rgba(0,0,0,.14)');
    grd.addColorStop(0.75, 'rgba(255,255,255,.2)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.beginPath(); g.arc(m, m, 55, 0, 7); g.fill();
    g.lineCap = 'round';
    g.lineJoin = 'round';
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + rand(-0.3, 0.3), r0 = rand(16, 26);
      strokeCrack(g, crackPath(m + Math.cos(a) * r0, m + Math.sin(a) * r0, a, rand(25, 55), 4), 0.9);
    }
    g.save();
    g.translate(m, m);
    g.rotate(ang + Math.PI / 2);
    g.fillStyle = 'rgba(0,0,0,.45)';
    for (let i = 0; i < 4; i++) {
      g.beginPath(); g.ellipse(-27 + i * 18, 0, 7, 5, 0, 0, 7); g.fill();
    }
    g.restore();
    return c;
  }

  function drawScorch(R) {
    const [c, g] = makeCanvas(R * 2.3), m = c._w / 2;
    g.save();
    g.filter = 'blur(3px)';
    g.beginPath();
    const n = 26;
    for (let i = 0; i <= n; i++) {
      const a = (i / n) * Math.PI * 2, r = R * rand(0.6, 0.9);
      const px = m + Math.cos(a) * r, py = m + Math.sin(a) * r;
      i ? g.lineTo(px, py) : g.moveTo(px, py);
    }
    g.closePath();
    const grd = g.createRadialGradient(m, m, 0, m, m, R * 0.9);
    grd.addColorStop(0, 'rgba(8,6,4,.92)');
    grd.addColorStop(0.45, 'rgba(30,20,12,.75)');
    grd.addColorStop(0.8, 'rgba(70,42,18,.35)');
    grd.addColorStop(1, 'rgba(90,55,20,0)');
    g.fillStyle = grd;
    g.fill();
    g.restore();
    g.lineCap = 'round';
    g.lineJoin = 'round';
    for (let i = 0; i < 9; i++) strokeCrack(g, crackPath(m, m, rand(0, Math.PI * 2), rand(R * 0.4, R * 1.05), 6), 1);
    g.fillStyle = 'rgba(255,120,30,.55)';
    for (let i = 0; i < 12; i++) {
      const a = rand(0, Math.PI * 2), r = rand(0, R * 0.6);
      g.beginPath(); g.arc(m + Math.cos(a) * r, m + Math.sin(a) * r, rand(1, 2.5), 0, 7); g.fill();
    }
    return c;
  }

  function drawArrowStuck(ang, power) {
    const [c, g] = makeCanvas(280), m = 140;
    const embed = 18 + power * 22;
    g.translate(m, m);
    g.rotate(ang);
    g.fillStyle = 'rgba(0,0,0,.25)';
    g.beginPath(); g.ellipse(-60 + embed / 2, 7, 60, 3, 0, 0, 7); g.fill();
    g.save();
    g.beginPath(); g.rect(-200, -40, 200, 80); g.clip();
    g.translate(-125 + embed, 0);
    drawArrowLocal(g, 125);
    g.restore();
    g.fillStyle = 'rgba(0,0,0,.75)';
    g.beginPath(); g.arc(0, 0, 3.5, 0, 7); g.fill();
    return c;
  }

  // ---------- Reação dos elementos ----------
  function targetAt(x, y) {
    const bar = hudRoot.getElementById('bar');
    fx.style.pointerEvents = 'none';
    bar.style.pointerEvents = 'none';
    let el = document.elementFromPoint(x, y);
    fx.style.pointerEvents = '';
    bar.style.pointerEvents = '';
    while (el && el !== document.body && el !== document.documentElement) {
      const cs = getComputedStyle(el);
      if (cs.display !== 'inline' && cs.display !== 'contents') {
        const r = el.getBoundingClientRect();
        return r.width * r.height < VW * VH * 0.5 ? el : null;
      }
      el = el.parentElement;
    }
    return null;
  }

  function hitAt(x, y, power, dir) {
    state.hits++;
    updateHud();
    const el = targetAt(x, y);
    if (el) hitEl(el, power, dir);
  }

  function hitEl(el, power, dir) {
    let d = damaged.get(el);
    if (!d) {
      const r = el.getBoundingClientRect();
      d = { hp: Math.max(2, Math.round(Math.sqrt(r.width * r.height) / 40)), tilt: 0, fallen: false };
      damaged.set(el, d);
    }
    if (d.fallen) return;

    const mag = Math.min(24, 4 + power * 4);
    const n = Math.hypot(dir.x, dir.y) || 1;
    const ux = (dir.x / n) * mag, uy = (dir.y / n) * mag;
    el.animate(
      [
        { transform: 'translate(0px,0px) rotate(0deg)' },
        { transform: `translate(${ux + rand(-mag, mag) * 0.4}px,${uy + rand(-mag, mag) * 0.4}px) rotate(${rand(-2, 2) * Math.min(power, 4)}deg)` },
        { transform: `translate(${-ux * 0.5}px,${-uy * 0.5}px) rotate(${rand(-1, 1)}deg)` },
        { transform: 'translate(0px,0px) rotate(0deg)' }
      ],
      { duration: 260, easing: 'ease-out', composite: 'add' }
    );

    const prev = d.tilt;
    d.tilt = clamp(d.tilt + rand(-1.6, 1.6) * Math.min(power, 3), -9, 9);
    d.tiltAnim?.cancel();
    d.tiltAnim = el.animate(
      [{ transform: `rotate(${prev}deg)` }, { transform: `rotate(${d.tilt}deg)` }],
      { duration: 160, fill: 'forwards', composite: 'add' }
    );

    d.hp -= power;
    if (d.hp <= 0) fall(el, d, dir);
  }

  function fall(el, d, dir) {
    d.fallen = true;
    const r = el.getBoundingClientRect();
    const dx = (dir.x >= 0 ? 1 : -1) * rand(40, 160);
    const rot = rand(-35, 35);
    const drop = VH - r.top + 250;
    d.fallAnim = el.animate(
      [
        { transform: 'translate(0px,0px) rotate(0deg)' },
        { transform: `translate(${dx * 0.1}px,8px) rotate(${rot * 0.25}deg)`, offset: 0.18 },
        { transform: `translate(${dx}px,${drop}px) rotate(${rot}deg)` }
      ],
      { duration: 1300, delay: 120, easing: 'cubic-bezier(.55,0,.9,.45)', fill: 'forwards', composite: 'add' }
    );
    for (let i = 0; i < 14; i++) {
      spawn({ kind: 'dust', x: rand(r.left, r.right), y: r.bottom, vx: rand(-60, 60), vy: rand(-60, -10), life: rand(0.6, 1), size: rand(10, 22), color: '#a39d93' });
    }
    tone(0.6, 'sine', 1300, 260, 0.07, 0.1);
    const L = r.left + scrollX, T = r.top + scrollY;
    for (let i = marks.length - 1; i >= 0; i--) {
      const m = marks[i];
      if (m._px >= L && m._px <= L + r.width && m._py >= T && m._py <= T + r.height) {
        m.remove();
        marks.splice(i, 1);
      }
    }
  }

  // ---------- Som (gerado com Web Audio, sem arquivos) ----------
  let ac = null, master = null, noiseBuf = null;

  function audio() {
    if (!state.sound) return null;
    try {
      if (!ac) {
        ac = new (window.AudioContext || window.webkitAudioContext)();
        const comp = ac.createDynamicsCompressor();
        comp.threshold.value = -14;
        comp.ratio.value = 6;
        master = ac.createGain();
        master.gain.value = 0.5;
        master.connect(comp).connect(ac.destination);
        const len = ac.sampleRate * 2;
        noiseBuf = ac.createBuffer(1, len, ac.sampleRate);
        const data = noiseBuf.getChannelData(0);
        for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      }
      if (ac.state === 'suspended') ac.resume();
      return ac;
    } catch {
      return null;
    }
  }

  function noise(dur, type, freq, vol, freqEnd, q = 1, delay = 0) {
    const a = audio();
    if (!a) return;
    const t = a.currentTime + delay;
    const src = a.createBufferSource();
    src.buffer = noiseBuf;
    src.loop = true;
    const f = a.createBiquadFilter();
    f.type = type;
    f.Q.value = q;
    f.frequency.setValueAtTime(freq, t);
    if (freqEnd) f.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    const g = a.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f).connect(g).connect(master);
    src.start(t, Math.random());
    src.stop(t + dur + 0.02);
  }

  function tone(dur, type, f0, f1, vol, delay = 0) {
    const a = audio();
    if (!a) return;
    const t = a.currentTime + delay;
    const o = a.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    const g = a.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  function glassSound(k) {
    for (let i = 0; i < 5; i++) {
      const f = rand(2500, 6000);
      tone(rand(0.12, 0.3), 'sine', f, f * 0.92, 0.07 * k, i * 0.02 + rand(0, 0.05));
    }
    noise(0.25, 'highpass', 4000, 0.25 * k);
  }

  function gunSound(w) {
    switch (w) {
      case 'pistola':
        noise(0.35, 'lowpass', 4000, 1, 200); tone(0.18, 'sine', 150, 40, 0.8); noise(0.04, 'highpass', 3000, 0.5);
        break;
      case 'mp5':
        noise(0.16, 'lowpass', 5000, 0.7, 500); tone(0.09, 'sine', 220, 70, 0.5); noise(0.03, 'highpass', 3500, 0.35);
        break;
      case 'm4':
        noise(0.22, 'lowpass', 6000, 0.85, 300); tone(0.12, 'sine', 170, 50, 0.6); noise(0.035, 'highpass', 4000, 0.5);
        break;
      case 'ak47':
        noise(0.3, 'lowpass', 3500, 1, 180); tone(0.16, 'sine', 120, 35, 0.9); noise(0.04, 'highpass', 2500, 0.5);
        break;
      case 'sniper':
        noise(0.9, 'lowpass', 5000, 1.2, 120); tone(0.5, 'sine', 90, 28, 1); noise(0.04, 'highpass', 3000, 0.8);
        noise(0.7, 'lowpass', 700, 0.3, 150, 1, 0.22);
        tone(0.03, 'square', 1300, 900, 0.12, 0.6); tone(0.03, 'square', 900, 700, 0.12, 0.75);
        break;
    }
  }

  // ---------- Barra de ferramentas na página ----------
  const SPEAKER_ON = '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/><path d="M19 6a8.5 8.5 0 0 1 0 12"/></svg>';
  const SPEAKER_OFF = '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M17 9l5 6M22 9l-5 6"/></svg>';
  const CHEV_UP = '<svg viewBox="0 0 24 24"><path d="M6 15l6-6 6 6"/></svg>';
  const CHEV_DOWN = '<svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>';

  function buildHud() {
    hudHost = document.createElement('div');
    hudHost.setAttribute('data-peia', 'hud');
    hudHost.style.cssText = `all:initial;position:fixed;top:12px;left:0;right:0;z-index:${Z + 2};display:none;pointer-events:none;`;
    hudRoot = hudHost.attachShadow({ mode: 'open' });
    hudRoot.innerHTML = `
      <style>
        :host { all: initial; }
        .wrap { display:flex; justify-content:center; padding:0 12px; }
        .bar { display:flex; flex-wrap:wrap; justify-content:center; align-items:center; gap:4px; padding:6px;
          max-width:100%; box-sizing:border-box; border-radius:16px;
          background:rgba(18,18,22,.92); backdrop-filter:blur(10px); border:1px solid rgba(255,255,255,.1);
          pointer-events:auto; box-shadow:0 10px 30px rgba(0,0,0,.35); font:500 12px/1 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
          color:#e9e9ee; user-select:none; }
        .armas { display:flex; flex-wrap:wrap; justify-content:center; align-items:center; gap:2px; }
        .grupo { display:flex; gap:2px; }
        button { all:unset; box-sizing:border-box; cursor:pointer; display:flex; align-items:center; justify-content:center;
          border-radius:10px; color:#c9c9d1; transition:background .12s,color .12s,transform .08s; }
        button:hover { background:rgba(255,255,255,.08); color:#fff; }
        button:active { transform:scale(.94); }
        .w { width:36px; height:36px; }
        .w.on { background:#ff4d2e; color:#fff; box-shadow:0 4px 14px rgba(255,77,46,.45); }
        svg { width:20px; height:20px; fill:none; stroke:currentColor; stroke-width:1.8; stroke-linecap:round; stroke-linejoin:round; }
        .sep { width:1px; height:26px; background:rgba(255,255,255,.12); margin:0 4px; }
        .atual { display:none; align-items:center; gap:8px; padding:0 8px; height:36px; font-weight:600; }
        .atual .ic { display:flex; color:#ff4d2e; }
        .hits { display:flex; flex-direction:column; align-items:center; gap:3px; min-width:50px; padding:0 4px; }
        .hits b { font-size:15px; font-weight:700; color:#fff; font-variant-numeric:tabular-nums; }
        .hits span { font-size:9px; opacity:.6; text-transform:uppercase; letter-spacing:.06em; }
        .a { height:36px; padding:0 10px; }
        .a.icon { width:36px; padding:0; }
        .x:hover { background:rgba(255,77,46,.18); color:#ff7a5f; }
        .bar.min .armas, .bar.min .sep.g { display:none; }
        .bar.min .atual { display:flex; }
      </style>
      <div class="wrap"><div class="bar" id="bar">
        <div class="armas">
          ${GROUPS.map((gr) => `<div class="grupo">${ARMAS.filter((a) => a.grupo === gr).map((a) => `<button class="w" data-w="${a.id}" title="${a.nome}: ${a.desc}">${a.icon}</button>`).join('')}</div>`).join('<div class="sep"></div>')}
        </div>
        <div class="atual"><span class="ic" id="ic"></span><span id="nome"></span></div>
        <div class="sep"></div>
        <div class="hits" title="Q e E ou botão direito trocam a arma"><b id="hits">0</b><span>golpes</span></div>
        <div class="sep"></div>
        <button class="a icon" id="som" title="Ligar ou desligar o som"></button>
        <button class="a" id="limpar" title="Remover todas as marcas">Limpar</button>
        <button class="a icon" id="min" title="Recolher ou expandir"></button>
        <button class="a icon x" id="sair" title="Sair (Esc)"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
      </div></div>`;

    hudRoot.querySelectorAll('.w').forEach((b) => b.addEventListener('click', () => setWeapon(b.dataset.w)));
    hudRoot.getElementById('som').addEventListener('click', () => {
      state.sound = !state.sound;
      try { chrome.storage.local.set({ sound: state.sound }).catch(() => {}); } catch {}
      updateHud();
    });
    hudRoot.getElementById('limpar').addEventListener('click', reset);
    hudRoot.getElementById('min').addEventListener('click', () => { state.minimized = !state.minimized; updateHud(); });
    hudRoot.getElementById('sair').addEventListener('click', deactivate);
  }

  function updateHud() {
    if (!hudRoot) return;
    const info = INFO[state.weapon] || {};
    hudRoot.querySelectorAll('.w').forEach((b) => b.classList.toggle('on', b.dataset.w === state.weapon));
    hudRoot.getElementById('bar').classList.toggle('min', state.minimized);
    hudRoot.getElementById('ic').innerHTML = info.icon || '';
    hudRoot.getElementById('nome').textContent = info.nome || '';
    hudRoot.getElementById('hits').textContent = state.hits;
    hudRoot.getElementById('som').innerHTML = state.sound ? SPEAKER_ON : SPEAKER_OFF;
    hudRoot.getElementById('min').innerHTML = state.minimized ? CHEV_DOWN : CHEV_UP;
  }

  // ---------- Mensagens do popup e do atalho ----------
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    switch (msg?.type) {
      case 'activate': activate(msg.weapon); break;
      case 'deactivate': deactivate(); break;
      case 'toggle': state.active ? deactivate() : activate(msg.weapon); break;
      case 'setWeapon': setWeapon(msg.weapon); break;
      case 'reset': reset(); break;
    }
    reply({ active: state.active, weapon: state.weapon, hits: state.hits });
  });
})();
